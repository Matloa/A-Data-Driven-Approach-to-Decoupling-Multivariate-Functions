% Experiment: Harder test functions
% Approach 2a = K-NN cluster,
% Approach 2b = fixed-radius cluster
% on progressively harder cases and
% compare against the polynomial-fit-then-decouple baseline on the same
% uniformly-sampled data cloud.
%
% Cases:
%   C1  Baseline cubic           (reference: should work)
%   C2  High-frequency sine ridge (fast fluctuation, polynomial G struggles)
%   C3  Quintic ridge            (sharper curvature than cubic)
%   C4  Rank-3 / 3x3 system      (more factors to separate)
%
% For each case: build the shared uniform cloud, run 2a, 2b, baseline,
% report relative Jacobian error, CPD error, and RMS on a clean test
% set.

clear all; close all; clc;

%% GLOBAL SETTINGS
N        = 800;     % cloud size 
N_test   = 300;
box_def  = 0.05;    % uniform half-width [-box, box]^m
K_nn     = 10;
radius   = 0.02;    % default radius (rescaled per-case below to ~0.4*box)
d_reg    = 5;       % regression degree for G (higher to follow wiggles)
cpd_tol  = 5e-2;    % looser: hard cases will not reach 1e-3
max_attempts = 15;

rng(1);

%% Define the test cases as anonymous-function factories.
% Each returns: F (handle R^m->R^n), Jfun (true Jacobian handle),
% Wo, Vo (for cpderr), gcell (true ridge fns), m, n, r, label.
% Each case also carries its own .box so we can show how the sampling
% region changes the outcome (uneven density at large box hurts K-NN).
cases = {};

%C1: baseline cubic (m=n=r=2)
C = make_case_cubic();              C.box = box_def;  cases{end+1} = C;

%C2a: sine ridge, SMALL box (samples dense, ~1 period)
C = make_case_sine(12);  C.label = 'C2a sine small-box'; C.box = 0.05;  cases{end+1} = C;

%C2b: sine ridge, LARGE box (many periods, uneven coverage)
C = make_case_sine(12);  C.label = 'C2b sine large-box'; C.box = 1.0;   cases{end+1} = C;

%C3: quintic ridge
C = make_case_quintic();            C.box = box_def;  cases{end+1} = C;

%C4: rank-3, 3x3 system
C = make_case_rank3();              C.box = box_def;  cases{end+1} = C;

%% Run every case
fprintf('%-22s  %-10s  %-12s  %-12s  %-12s\n', ...
    'Case', 'method', 'RelJac', 'CPDerr', 'RelRMS');
fprintf('\n');

for ci = 1:numel(cases)
    C = cases{ci};
    m = C.m; n = C.n; r = C.r;
    box = C.box;                          % per-case sampling half-width
    rad = max(radius, 0.4 * box);         % keep radius proportional to box

    % shared cloud
    X = box * (2*rand(m, N) - 1);
    Y = zeros(n, N);
    for k = 1:N, Y(:,k) = C.F(X(:,k)); end
    Xt = box * (2*rand(m, N_test) - 1);
    Yt = zeros(n, N_test);
    for k = 1:N_test, Yt(:,k) = C.F(Xt(:,k)); end
    Phi = poly_features(X, m, d_reg);

    % output scale for relative RMS: RMS of ||F|| over the test set
    Fnorm = sqrt(mean(sum(Yt.^2, 1)));    % scalar, > 0

    % cluster tensors
    Ta = build_knn_tensor(X, Y, K_nn, m, n);
    Tb = build_radius_tensor(X, Y, rad, m, n, C.F);

    ja = mean(jac_rel_error(Ta, X, C.Jfun));
    jb = mean(jac_rel_error(Tb, X, C.Jfun));

    [ra, ca] = cluster_pipe(Ta, X, Y, Xt, Yt, C.Wo, C.Vo, r, d_reg, cpd_tol, max_attempts);
    [rb, cb] = cluster_pipe(Tb, X, Y, Xt, Yt, C.Wo, C.Vo, r, d_reg, cpd_tol, max_attempts);
    [rbase, cbase, jbase] = baseline_pipe(X, Y, Phi, Xt, Yt, C.Wo, C.Vo, ...
        r, d_reg, m, n, cpd_tol, max_attempts, C.Jfun);

    % relative RMS (scale-invariant, comparable across cases)
    ra_rel = ra / Fnorm;  rb_rel = rb / Fnorm;  rbase_rel = rbase / Fnorm;

    fprintf('%-22s  %-10s  %-12.2e  %-12.2e  %-12.2e\n', C.label, '2a (KNN)',  ja, ca, ra_rel);
    fprintf('%-22s  %-10s  %-12.2e  %-12.2e  %-12.2e\n', '',       '2b (rad)',  jb, cb, rb_rel);
    fprintf('%-22s  %-10s  %-12.2e  %-12.2e  %-12.2e\n', '',       'baseline',  jbase, cbase, rbase_rel);
    fprintf('\n');

    % store for plotting (relative RMS now)
    cases{ci}.X = X;
    cases{ci}.summary = [ja ca ra_rel; jb cb rb_rel; jbase cbase rbase_rel];
end

%% Coverage contrast: SAME sine, small box (C2a) vs large box (C2b)
%% Shows that at small box the samples densely cover ~1 period, while at
%% large box they thin out across many periods -> uneven coverage.
idx_small = find(strcmp(cellfun(@(c) c.label, cases, 'UniformOutput', false), 'C2a sine small-box'));
idx_large = find(strcmp(cellfun(@(c) c.label, cases, 'UniformOutput', false), 'C2b sine large-box'));
figure('Name', 'Sine coverage: small box vs large box');
panel = 0;
for which = [idx_small, idx_large]
    C = cases{which};
    U = C.Vo' * C.X;
    for i = 1:C.r
        panel = panel + 1;
        subplot(2, C.r, panel);
        ug = linspace(min(U(i,:)), max(U(i,:)), 600);
        plot(ug, C.gcell{i}(ug), 'k-', 'LineWidth', 1.0); hold on;
        plot(U(i,:), C.gcell{i}(U(i,:)), 'b.', 'MarkerSize', 6);
        xlabel(sprintf('u_%d', i)); ylabel(sprintf('g_%d', i));
        title(sprintf('%s: g_%d', C.label, i));
        grid on;
    end
end

%% Bar chart: RELATIVE RMS per case per method (scale-invariant)
labels = cellfun(@(c) c.label, cases, 'UniformOutput', false);
RelRMS = zeros(numel(cases), 3);
for ci = 1:numel(cases), RelRMS(ci,:) = cases{ci}.summary(:,3)'; end
figure('Name', 'Relative RMS by test case and method');
bar(RelRMS);
set(gca, 'XTickLabel', labels, 'XTickLabelRotation', 20, 'YScale', 'log');
ylabel('Relative RMS  (RMS / ||F||_{test})');
legend({'2a (K-NN)', '2b (radius)', 'baseline'}, 'Location', 'northwest');
title('Where the methods struggle (scale-invariant)');
grid on;

%% TEST-CASE FACTORIES

function C = make_case_cubic()
    C.m = 2; C.n = 2; C.r = 2; C.label = 'C1 cubic (easy)';
    C.Vo = [-3 0; 1 -8];
    C.Wo = [-2 3; -7 -4];
    C.gcell = {@(u) -2*u.^3 + u.^2 - 2*u, @(u) -u.^3 + 7*u.^2 + 3*u + 2};
    [C.F, C.Jfun] = build_FJ(C.Wo, C.Vo, C.gcell, ...
        {@(u) -6*u.^2 + 2*u - 2, @(u) -3*u.^2 + 14*u + 3});
end

function C = make_case_sine(freq)
    C.m = 2; C.n = 2; C.r = 2;
    C.label = sprintf('C2 sine f=%d (hard)', freq);
    C.Vo = [-3 0; 1 -8];
    C.Wo = [-2 3; -7 -4];
    C.gcell = {@(u) sin(freq*u), @(u) cos(freq*u)};
    C.gprime = {@(u) freq*cos(freq*u), @(u) -freq*sin(freq*u)};
    [C.F, C.Jfun] = build_FJ(C.Wo, C.Vo, C.gcell, C.gprime);
end

function C = make_case_quintic()
    C.m = 2; C.n = 2; C.r = 2; C.label = 'C3 quintic';
    C.Vo = [-3 0; 1 -8];
    C.Wo = [-2 3; -7 -4];
    C.gcell  = {@(u) u.^5 - 3*u.^3 + u, @(u) -2*u.^5 + u.^2};
    C.gprime = {@(u) 5*u.^4 - 9*u.^2 + 1, @(u) -10*u.^4 + 2*u};
    [C.F, C.Jfun] = build_FJ(C.Wo, C.Vo, C.gcell, C.gprime);
end

function C = make_case_rank3()
    C.m = 3; C.n = 3; C.r = 3; C.label = 'C4 rank-3 (3x3)';
    C.Vo = [2 1 0; 1 0 3; 0 2 -1];
    C.Wo = [1 0 1; -2 -1 1; 0 2 -1];
    C.gcell  = {@(u) 3*u.^3 - u.^2 + 5, @(u) -5*u.^3 + 3*u - 7, ...
                @(u) 2*u.^3 - 2*u + 2};
    C.gprime = {@(u) 9*u.^2 - 2*u, @(u) -15*u.^2 + 3, @(u) 6*u.^2 - 2};
    [C.F, C.Jfun] = build_FJ(C.Wo, C.Vo, C.gcell, C.gprime);
end

% Build F and the analytic Jacobian handle from W, V, g, g'.
function [F, Jfun] = build_FJ(W, V, gcell, gpcell)
    r = numel(gcell);
    F = @(x) W * cellfun_eval(gcell, V' * x, r);
    Jfun = @(x) W * diag(cellfun_eval(gpcell, V' * x, r)) * V';
end

function out = cellfun_eval(gc, u, r)
    out = zeros(r, 1);
    for i = 1:r, out(i) = gc{i}(u(i)); end
end

%% PIPELINE + HELPERS  (same logic as CoreBenchmarkComparison.m)

function T = build_knn_tensor(X, Y, K, m, n)
    N = size(X, 2);
    T = zeros(n, m, N);
    for c = 1:N
        xc = X(:,c); yc = Y(:,c);
        dists = sqrt(sum((X - xc).^2, 1)); dists(c) = Inf;
        [~, idx] = sort(dists);
        nn = idx(1:K);
        dX = X(:, nn) - xc; dY = Y(:, nn) - yc;
        w  = 1 ./ sqrt(sum(dX.^2, 1));
        T(:,:,c) = (dY .* w) * pinv(dX .* w);
    end
end

function T = build_radius_tensor(X, Y, radius, m, n, F)
    N = size(X, 2);
    T = zeros(n, m, N);
    for c = 1:N
        xc = X(:,c); yc = Y(:,c);
        dists = sqrt(sum((X - xc).^2, 1));
        nn = find((dists > 0) & (dists < radius));
        if numel(nn) >= m + 1
            dX = X(:, nn) - xc; dY = Y(:, nn) - yc;
            w  = 1 ./ sqrt(sum(dX.^2, 1));
            T(:,:,c) = (dY .* w) * pinv(dX .* w);
        else
            T(:,:,c) = numjac(F, xc);
        end
    end
end

function e = jac_rel_error(T, X, Jfun)
    N = size(X, 2); e = zeros(1, N);
    for k = 1:N
        Jt = Jfun(X(:,k));
        e(k) = norm(Jt - T(:,:,k), 'fro') / (norm(Jt, 'fro') + eps);
    end
end

function [rms, cpd_e] = cluster_pipe(T, X, Y, Xt, Yt, Wo, Vo, r, d, tol, maxa)
    best = Inf; W = []; V = [];
    for a = 1:maxa
        rc = cpd(T, r);
        ce = norm(cpderr({Wo, Vo}, {rc{1}, rc{2}}));
        if ce < best, best = ce; W = rc{1}; V = rc{2}; end
        if best < tol, break; end
    end
    cpd_e = best;
    U = V' * X; Yh = W \ Y;
    mu = mean(U, 2); sg = std(U, 0, 2);
    G = zeros(r, d+1);
    for i = 1:r, G(i,:) = polyfit((U(i,:) - mu(i)) / sg(i), Yh(i,:), d); end
    err = zeros(1, size(Xt, 2));
    for k = 1:size(Xt, 2)
        uk = V' * Xt(:,k); us = (uk - mu) ./ sg;
        gk = arrayfun(@(i) polyval(G(i,:), us(i)), (1:r)');
        err(k) = norm(Yt(:,k) - W * gk);
    end
    rms = sqrt(mean(err.^2));
end

function [rms, cpd_e, ej] = baseline_pipe(X, Y, Phi, Xt, Yt, Wo, Vo, r, d, m, n, tol, maxa, Jfun)
    N = size(X, 2);
    C = Y / Phi;
    T = zeros(n, m, N);
    for k = 1:N
        for j = 1:m
            T(:,j,k) = C * poly_features_deriv(X(:,k), m, d, j);
        end
    end
    ej = mean(jac_rel_error(T, X, Jfun));
    best = Inf; W = []; V = [];
    for a = 1:maxa
        rc = cpd(T, r);
        ce = norm(cpderr({Wo, Vo}, {rc{1}, rc{2}}));
        if ce < best, best = ce; W = rc{1}; V = rc{2}; end
        if best < tol, break; end
    end
    cpd_e = best;
    Yvals = C * Phi;
    U = V' * X; Yh = W \ Yvals;
    mu = mean(U, 2); sg = std(U, 0, 2);
    G = zeros(r, d+1);
    for i = 1:r, G(i,:) = polyfit((U(i,:) - mu(i)) / sg(i), Yh(i,:), d); end
    err = zeros(1, size(Xt, 2));
    for k = 1:size(Xt, 2)
        uk = V' * Xt(:,k); us = (uk - mu) ./ sg;
        gk = arrayfun(@(i) polyval(G(i,:), us(i)), (1:r)');
        err(k) = norm(Yt(:,k) - W * gk);
    end
    rms = sqrt(mean(err.^2));
end

function Phi = poly_features(X, m, d)
    N = size(X, 2); E = build_exponents(m, d); B = size(E, 1);
    Phi = ones(B, N);
    for b = 1:B
        for j = 1:m, Phi(b,:) = Phi(b,:) .* (X(j,:) .^ E(b,j)); end
    end
end

function dPhi = poly_features_deriv(x, m, d, j)
    E = build_exponents(m, d); B = size(E, 1); dPhi = zeros(B, 1);
    for b = 1:B
        ej = E(b, j);
        if ej == 0, continue; end
        val = ej;
        for jj = 1:m
            if jj == j, val = val * x(jj)^(ej - 1);
            else, val = val * x(jj)^E(b,jj); end
        end
        dPhi(b) = val;
    end
end

function E = build_exponents(m, d)
    E = [];
    for total = 0:d, E = [E; exponent_combos(m, total)]; end 
end

function C = exponent_combos(m, total)
    if m == 1, C = total; return; end
    C = [];
    for k = 0:total
        sub = exponent_combos(m-1, total-k);
        C = [C; k*ones(size(sub,1),1), sub]; 
    end
end

function J = numjac(F, x, h)
    if nargin < 3, h = 1e-5; end
    fx = F(x); fx = fx(:); n = numel(fx); m = numel(x);
    J = zeros(n, m);
    for j = 1:m
        xp = x; xm = x; xp(j) = xp(j)+h; xm(j) = xm(j)-h;
        J(:,j) = (F(xp) - F(xm)) / (2*h);
    end
end