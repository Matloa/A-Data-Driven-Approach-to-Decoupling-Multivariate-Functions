# A Data-Driven Approach to Decoupling Multivariate Functions

**Author:** Alexander Matlok  
**Program:** BSc Data Science and Artificial Intelligence, Maastricht University  
**Supervisor:** Philippe Dreesen

## Overview
This repository contains the MATLAB implementation for decoupling multivariate nonlinear functions using a purely data-driven approach. The core objective is to recover the decoupled structure **F(x) = W * G(V'x)** directly from scattered data without requiring a globally differentiable analytical model. 

The pipeline estimates local Jacobians from scattered data points, stacks them into a 3D tensor, applies Canonical Polyadic Decomposition (CPD) to recover the linear mixing matrices (**W** and **V**), and reconstructs the inner ridge functions (**G**) via polynomial regression.

## Prerequisites
To run the scripts in this repository, you will need:
* **MATLAB** (R2021a or newer recommended)
* **Tensorlab 3.0** (Required for the `cpd()` and `cpderr()` functions used in tensor decomposition.)
* **Statistics and Machine Learning Toolbox** (for standard data generation and statistical functions)

## Repository Structure
The code is divided into standalone experiment scripts that validate different aspects of the pipeline. Each script can be run independently and will generate the relevant console outputs and figures.

### 1. Core Comparisons
* **`BaselineComparison.m`** Performs a fair, side-by-side comparison on an identical uniformly sampled dataset. Compares the $K$-nearest-neighbour (Approach 2a) and fixed-radius (Approach 2b) cluster estimators against a global polynomial-fit-then-decouple baseline.

### 2. Jacobian Estimation & Neighborhoods
* **`Experiment_Cluster_KNN.m`** *(Note: Ensure you have saved your KNN script with this name)*
  Validates the $K$-nearest-neighbour approach for local Jacobian estimation, showing the bias-variance tradeoff across different values of $K$.
* **`RadiusBasedNeighbourhood.m`** Validates the fixed-radius local Jacobian estimator, testing how different physical scales impact the conditioning of the least-squares problem.

### 3. Hyperparameter Sweeps & Robustness
* **`OptimalKVsNoise.m`** A 2D sweep demonstrating how output noise levels dictate the optimal number of neighbours ($K$) needed to balance noise suppression against truncation bias.
* **`OptimalTrainingSizeVsNoise.m`** Evaluates the regression stage by sweeping the training pool size ($N_{reg}$) under varying noise conditions to show how statistical averaging dampens output variance.
* **`InfluenceHOnJacobianErrorAndRMS.m`** Validates the black-box central difference estimator by sweeping the step size ($h$) to illustrate the V-shaped tradeoff between truncation error and floating-point cancellation.

### 4. Scalability and Harder Benchmarks
* **`HigherDimensionalValidation.m`** & **`ExperimentMNotEqualsN.m`**
  Tests the pipeline on asymmetric ($m \neq n$) and higher-dimensional systems (e.g., $10 \times 10$) to confirm CPD stability as problem size increases.
* **`HarderTestFunctionsm.m`** Pushes the pipeline to its limits using higher-degree polynomials (quintic), higher rank systems (rank-3), and non-polynomial functions (high-frequency sine ridges). This isolates the polynomial regression stage as the bottleneck for periodic functions.

### 5. Demo of the Pipeline
**`demo.m`** provides a minimal end‑to‑end example of the full decoupling pipeline:
1. Generates a small synthetic dataset  
2. Estimates Jacobians using the K‑NN cluster method  
3. Builds the Jacobian tensor  
4. Runs CPD to recover **W** and **V** 5. Fits the ridge functions **g₁, g₂** 6. Evaluates the reconstructed model on a test point  

This script is the fastest way to understand how the entire pipeline works.

## How to Run
1. Ensure that the **Tensorlab 3.0** library is downloaded, extracted, and added to your MATLAB path.
2. Open any of the experiment scripts in MATLAB.
3. Click **Run**. 
4. The script will automatically output relative Jacobian errors, CPD errors, and RMS reconstruction errors to the command window, followed by generating all associated data visualizations.

## Implementation Notes
* **Data Generation:** Synthetic data is generated using uniform box sampling (e.g., `[-a, a]^m`) to ensure even spatial distribution and avoid the clustering at the origin that occurs with standard normal distributions.
* **Non-Convexity:** The CPD step uses local optimization. A retry loop is implemented in every script to mitigate the risk of landing in a local minimum.