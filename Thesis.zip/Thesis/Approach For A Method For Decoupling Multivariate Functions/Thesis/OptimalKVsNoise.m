% Experiment: Optimal K vs Noise Level
%   Low noise  -> small K is fine (local estimates are accurate)
%   High noise -> larger K needed (averaging over more neighbours
%                 suppresses noise, similar to OptimalTrainingSizeVsNoise)
%   Very large K -> neighbours are far away -> linearisation breaks down
%                   (O(sigma^2) error from nonlinearity of F)
% So for each noise level there should be an optimal K that balances
% noise suppression against error.

clear all; close all; clc;

%% PARAMETERS
m      = 2;    % number of inputs
n      = 2;    % number of outputs
r      = 2;    % rank (number of ridge functions)
d      = 3;    % polynomial degree for G recovery
N      = 500;  % size of data cloud
N_test = 200;  % number of test points
a      = 0.5;  % half-width of the box domain; tune this value as needed

syms u1 u2
Vo = [-3  0 ; ...
       1 -8 ];
Wo = [-2  3 ; ...
      -7 -4 ];
Go = [- 2*u1^3 +   u1^2 - 2*u1 ; - u2^3 + 7*u2^2 + 3*u2 + 2];

Fo_symbolic = expand(Wo*subs(Go,symvar(Go).',Vo'*sym('x', [1 m]).'));
Fo        = matlabFunction(Fo_symbolic, 'Vars', {sym('x', [m 1])});
xsym      = sym('x', [m 1]);
J_sym_fun = matlabFunction(jacobian(Fo_symbolic, xsym), 'Vars', {xsym});

fprintf('Building data cloud (N=%d, a=%.3f)...\n', N, a);
% Using uniform box sampling to avoid zero-clustering.
rng(42); 
X_data  = a * (2 * rand(m, N) - 1);
Y_clean = zeros(n, N);
for k = 1:N
    Y_clean(:,k) = Fo(X_data(:,k));
end

% Fixed clean test set — same distribution as training data
X_test = a * (2 * rand(m, N_test) - 1);
Y_test = zeros(n, N_test);
for k = 1:N_test
    Y_test(:,k) = Fo(X_test(:,k));
end

K_values           = [3, 5, 10, 20, 50];
sigma_noise_values = [0, 0.001, 0.01, 0.05, 0.1, 0.5];
n_K     = numel(K_values);
n_noise = numel(sigma_noise_values);

rms_grid     = zeros(n_noise, n_K);   % RMS reconstruction error
jac_err_grid = zeros(n_noise, n_K);   % Mean Jacobian Frobenius error
cpd_tol      = 1e-2;   % cluster noise floor limits CPD to ~1e-3
max_attempts = 10;

fprintf('\nSweeping K x sigma_noise...\n');
fprintf('%-10s  %-6s  %-18s  %-18s\n', 'sigma_noise', 'K', 'Mean Jac Error', 'RMS Recon Error');
fprintf('%s\n', repmat('-', 1, 58));

for ni = 1:n_noise
    sig     = sigma_noise_values(ni);
    Y_noisy = Y_clean + sig * randn(n, N);

    for ki = 1:n_K
        K_val = K_values(ki);
        
        % Build Jacobian tensor using K-NN on CLEAN X (noise only on Y)
        T_knn = zeros(n, m, N);
        for c = 1:N
            xc       = X_data(:, c);
            yc       = Y_clean(:, c);   % use clean Y for Jacobian estimation
            diffs    = X_data - xc;
            dists    = sqrt(sum(diffs.^2, 1));
            dists(c) = Inf;
            [~, idx] = sort(dists);
            nn_idx   = idx(1:K_val);
            
            dX = X_data(:, nn_idx) - xc;
            dY = Y_clean(:, nn_idx) - yc;
            w  = 1 ./ sqrt(sum(dX.^2, 1));
            T_knn(:,:,c) = (dY .* w) * pinv(dX .* w);
        end
        
        % Jacobian error (vs symbolic, unaffected by output noise) 
        ej = zeros(1, N);
        for k = 1:N
            J_true = J_sym_fun(X_data(:,k));
            ej(k)  = norm(J_true - T_knn(:,:,k), 'fro') / ...
                     (norm(J_true, 'fro') + eps);   % relative error
        end
        jac_err_grid(ni, ki) = mean(ej);
        
        % CPD with retry — keep best solution 
        best_err = Inf;  W_k = [];  V_k = [];
        for attempt = 1:max_attempts
            rc = cpd(T_knn, r);
            ce = norm(cpderr({Wo, Vo}, {rc{1}, rc{2}}));
            if ce < best_err
                best_err = ce;
                W_k = rc{1};  V_k = rc{2};
            end
            if best_err < cpd_tol, break; end
        end

        % If CPD failed to produce factors, mark as NaN and continue
        if isempty(V_k) || isempty(W_k) || ~isfinite(best_err)
            rms_grid(ni, ki)     = NaN;
            jac_err_grid(ni, ki) = NaN;
            fprintf('sig = %-7.3f  K = %-4d  CPD failed, skipping.\n', sig, K_val);
            continue;
        end
        
        % Polynomial regression on NOISY Y 
        U_k    = V_k' * X_data;      % r x N
        Yhat_k = W_k  \ Y_noisy;     % r x N

        % Normalisation (avoid zero std)
        U_mu_k  = mean(U_k, 2);
        U_sig_k = std(U_k, 0, 2);
        U_sig_k(U_sig_k == 0) = 1;   % prevent division by zero
        
        G_poly_k = zeros(r, d+1);
        for i = 1:r
            Us = (U_k(i,:) - U_mu_k(i)) / U_sig_k(i);
            G_poly_k(i,:) = polyfit(Us, Yhat_k(i,:), d);
        end
        
        % RMS on clean test set
        err_k = zeros(1, N_test);
        for k = 1:N_test
            u_k      = V_k' * X_test(:,k);          % r x 1
            u_scaled = (u_k - U_mu_k) ./ U_sig_k;   % r x 1
            g_k      = arrayfun(@(i) polyval(G_poly_k(i,:), u_scaled(i)), (1:r)');
            err_k(k) = norm(Y_test(:,k) - W_k * g_k);
        end
        rms_grid(ni, ki) = sqrt(mean(err_k.^2));
        
        fprintf('sig = %-7.3f  K = %-4d  jac = %-14.2e  rms = %-14.2e\n', ...
            sig, K_val, jac_err_grid(ni, ki), rms_grid(ni, ki));
    end
end

%%Find optimal K for each noise level
fprintf('\n%-12s  %-14s  %-14s\n', 'sigma_noise', 'Optimal K', 'Best RMS');
fprintf('%s\n', repmat('-', 1, 44));
optimal_K   = zeros(1, n_noise);
optimal_rms = zeros(1, n_noise);
for ni = 1:n_noise
    [best_rms, best_ki] = min(rms_grid(ni,:));
    optimal_K(ni)   = K_values(best_ki);
    optimal_rms(ni) = best_rms;
    fprintf('sig = %-7.3f  K* = %-10d  rms* = %.2e\n', ...
        sigma_noise_values(ni), optimal_K(ni), best_rms);
end

%%Plots

% 1) RMS curves for each noise level as function of K
figure('Name', 'Optimal K vs Noise: RMS curves');
colors = lines(n_noise);
hold on;
for ni = 1:n_noise
    plot(K_values, rms_grid(ni,:), '-o', 'Color', colors(ni,:), ...
        'LineWidth', 1.5, 'MarkerFaceColor', colors(ni,:), ...
        'DisplayName', sprintf('\\sigma = %.3f', sigma_noise_values(ni)));
end
set(gca, 'YScale', 'log', 'XScale', 'log');
xlabel('K (number of neighbours)');
ylabel('RMS reconstruction error (clean test set)');
title('RMS vs K for each noise level');
legend('Location', 'best');
grid on;

% 2) Optimal K vs noise level
figure('Name', 'Optimal K vs Noise: optimal K');
semilogx(sigma_noise_values + 1e-4, optimal_K, 'k-o', ...
    'LineWidth', 2, 'MarkerFaceColor', 'k', 'MarkerSize', 8);
xlabel('Noise level \sigma_{noise}');
ylabel('Optimal K (neighbours)');
title('How many neighbours are needed vs noise level?');
grid on;

% 3) RMS heatmap
figure('Name', 'Optimal K vs Noise: RMS heatmap');
imagesc(log10(K_values), 1:n_noise, log10(rms_grid));
colorbar;
xlabel('log_{10}(K)');
ylabel('Noise level \sigma_{noise}');
yticks(1:n_noise);
yticklabels(arrayfun(@(s) sprintf('%.3f', s), sigma_noise_values, 'UniformOutput', false));
title('log_{10}(RMS) — darker = lower error');
colormap(flipud(parula));

% 4) Jacobian error heatmap
figure('Name', 'Optimal K vs Noise: Jacobian error heatmap');
imagesc(log10(K_values), 1:n_noise, log10(jac_err_grid));
colorbar;
xlabel('log_{10}(K)');
ylabel('Noise level \sigma_{noise}');
yticks(1:n_noise);
yticklabels(arrayfun(@(s) sprintf('%.3f', s), sigma_noise_values, 'UniformOutput', false));
title('log_{10}(Mean relative Jac error) — darker = lower error');
colormap(flipud(parula));

annotation('textbox', [0.1, 0.01, 0.8, 0.06], 'String', ...
    ['Observation: Under uniform box sampling, increasing noise requires a larger neighborhood size K ', ...
     'to leverage local averaging. However, if K is too large, the local linearity assumption deteriorates, ', ...
     'introducing truncation errors from distant geometry across the workspace limits.'], ...
    'EdgeColor', 'none', 'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold');

