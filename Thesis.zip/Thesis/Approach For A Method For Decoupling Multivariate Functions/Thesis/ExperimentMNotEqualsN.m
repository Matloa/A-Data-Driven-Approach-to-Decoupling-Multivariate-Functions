    % Experiment M not equals N : R^m -> R^n  with m ~= n
    % The standard demo uses m = n = 2.
    % Here we test m = 2 inputs, n = 3 outputs so the Jacobian
    % slices T(:,:,k) are 3 x 2 and the full tensor is 3 x 2 x N.
    
    clear all; close all; clc;
    
    %% PARAMETERS
    m      = 2;    % number of inputs
    n      = 3;    % number of outputs (different from m)
    r      = 2;    % rank (number of ridge functions)
    d      = 3;    % polynomial degree for G recovery
    N      = 500;  % number of training points
    N_test = 200;  % number of test points
    a      = 0.5;  % half-width of the box domain; tune this value as needed
    
    % Wo is n x r = 3 x 2,  Vo is m x r = 2 x 2.
    % The Jacobian dF/dx is n x m = 3 x 2 at every point,
    % so the Jacobian tensor T is  3 x 2 x N.
    syms u1 u2
    Vo = [-3  0 ; ...
           1 -8 ];
    Wo = [-2  3 ; ...
          -7 -4 ; ...
           1  2 ];
    Go = [- 2*u1^3 +   u1^2 - 2*u1 ; - u2^3 + 7*u2^2 + 3*u2 + 2];
    
    % Sanity check: expanding Wo*Go(Vo'*x) symbolically should recover F.
    Fo_symbolic = expand(Wo*subs(Go,symvar(Go).',Vo'*sym('x', [1 m]).'))
    Fo        = matlabFunction(Fo_symbolic, 'Vars', {sym('x', [m 1])});
    xsym      = sym('x', [m 1]);
    J_sym_fun = matlabFunction(jacobian(Fo_symbolic, xsym), 'Vars', {xsym});
    
    % T is now  n x m x N  =  3 x 2 x N.
    % Each slice T(:,:,k) is the 3 x 2 Jacobian at X(:,k).
    % Using uniform box sampling to avoid zero-clustering.
    X = a * (2 * rand(m, N) - 1);
    Y = zeros(n, N);
    T = zeros(n, m, N);
    for k = 1:N
        xk       = X(:,k);
        Y(:,k)   = Fo(xk);
        T(:,:,k) = numjac(Fo, xk);
    end
    
    % Relative error = ||J_sym - J_num||_F / ||J_sym||_F
    % is more informative than the absolute error when Jacobian
    % entries vary in magnitude across the input space.
    err_jac_abs = zeros(1, N);
    err_jac_rel = zeros(1, N);
    for k = 1:N
        J_true         = J_sym_fun(X(:,k));
        J_num          = T(:,:,k);
        err_jac_abs(k) = norm(J_true - J_num, 'fro');
        err_jac_rel(k) = norm(J_true - J_num, 'fro') / (norm(J_true, 'fro') + eps);
    end
    fprintf('\n=== Jacobian validation over %d points (m=%d, n=%d) ===\n', N, m, n);
    fprintf('  Mean absolute Frobenius error: %.2e\n', mean(err_jac_abs));
    fprintf('  Max  absolute Frobenius error: %.2e\n', max(err_jac_abs));
    fprintf('  Mean relative Frobenius error: %.2e\n', mean(err_jac_rel));
    fprintf('  Max  relative Frobenius error: %.2e\n', max(err_jac_rel));
    
    % CPD of a  3 x 2 x N  tensor returns:
    %   res{1} = W_est  of size  n x r = 3 x 2
    %   res{2} = V_est  of size  m x r = 2 x 2
    % CPD uses local optimisation and may land in a local minimum.
    % We retry until the error is below the threshold.
    cpd_tol      = 1e-4;
    max_attempts = 10;
    cpderror_J   = Inf;
    attempt      = 0;
    while cpderror_J >= cpd_tol && attempt < max_attempts
        attempt = attempt + 1;
        res     = cpd(T, r);
        W_est   = res{1};
        V_est   = res{2};
        cpderror_J = norm(cpderr({Wo, Vo}, {W_est, V_est}));
        fprintf('CPD attempt %d: error = %.2e\n', attempt, cpderror_J);
    end
    fprintf('\nWo (true, %d x %d):\n', n, r);  disp(Wo);
    fprintf('W_est (est, %d x %d):\n', n, r);  disp(W_est);
    fprintf('Vo (true, %d x %d):\n', m, r);    disp(Vo);
    fprintf('V_est (est, %d x %d):\n', m, r);  disp(V_est);
    fprintf('CPD error: %.2e  (after %d attempt(s))\n', cpderror_J, attempt);
    if cpderror_J < cpd_tol
        disp('Good result!');
    else
        warning('CPD did not converge to a good solution after %d attempts.', max_attempts);
    end
    
    % W_est \ Y is a least-squares solve because W_est is 3 x 2
    % (more rows than columns). MATLAB backslash handles this automatically.
    U    = V_est' * X;
    Yhat = W_est \ Y;
    U_mu  = mean(U, 2);
    U_sig = std(U, 0, 2);
    G_poly = zeros(r, d+1);
    for i = 1:r
        U_scaled    = (U(i,:) - U_mu(i)) / U_sig(i);
        G_poly(i,:) = polyfit(U_scaled, Yhat(i,:), d);
    end
    fprintf('\nRecovered G coefficients (highest to lowest degree):\n');
    for i = 1:r
        fprintf('  g%d: ', i);
        fprintf('%+.4f  ', G_poly(i,:));
        fprintf('\n');
    end
    
    % Using uniform box sampling to avoid zero-clustering on test set.
    X_test = a * (2 * rand(m, N_test) - 1);
    err    = zeros(1, N_test);
    for k = 1:N_test
        u_k      = V_est' * X_test(:,k);
        u_scaled = (u_k - U_mu) ./ U_sig;
        g_k      = arrayfun(@(i) polyval(G_poly(i,:), u_scaled(i)), (1:r)');
        err(k)   = norm(Fo(X_test(:,k)) - W_est * g_k);
    end
    fprintf('RMS reconstruction error (m=%d, n=%d): %.2e\n', m, n, sqrt(mean(err.^2)));
    
    function J = numjac(Fo, x, h)
        if nargin < 3, h = 1e-5; end
        fx = Fo(x);
        fx = fx(:);
        n  = numel(fx);
        m  = numel(x);
        J  = zeros(n, m);
        for j = 1:m
            xp    = x;
            xm    = x;
            xp(j) = xp(j) + h;
            xm(j) = xm(j) - h;
            fxp   = Fo(xp);
            fxm   = Fo(xm);
            J(:,j) = (fxp(:) - fxm(:)) / (2*h);
        end
    end