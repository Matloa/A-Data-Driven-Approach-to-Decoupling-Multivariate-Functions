% Experiment Cluster Jacobian approximation
% For each centre point x_c we find the K nearest neighbours and
% estimate the Jacobian by least-squares from the neighbour displacements:
%
%   delta_x_k = x_k - x_c       (m x 1)
%   delta_y_k = y_k - y_c       (n x 1)
%
%   J_est = dY_w * pinv(dX_w)   (n x m, weighted least-squares)

clear all; close all; clc;

m      = 2;
n      = 2;
r      = 2;
d      = 3;
N      = 500;
N_test = 200;
K      = 10;
a      = 0.5;  % half-width of the box domain; tune this value as needed

syms u1 u2
Vo = [-3  0 ; ...
       1 -8 ];
Wo = [-2  3 ; ...
      -7 -4 ];
Go = [- 2*u1^3 +   u1^2 - 2*u1 ; - u2^3 + 7*u2^2 + 3*u2 + 2];

Fo_symbolic = expand(Wo*subs(Go,symvar(Go).',Vo'*sym('x', [1 m]).'));
Fo        = matlabFunction(Fo_symbolic, 'Vars', {sym('x', [m 1])});
xsym      = sym('x', [m 1]);
J_sym_fun = matlabFunction(jacobian(Fo_symbolic, xsym), 'Vars', {xsym});

% Using uniform box sampling to avoid zero-clustering.
X_data = a * (2 * rand(m, N) - 1);
Y_data = zeros(n, N);
for k = 1:N
    Y_data(:,k) = Fo(X_data(:,k));
end

n_probe = 8;
fprintf('\n=== Intermediate manual check: %d probe points ===\n', n_probe);
fprintf('%-6s  %-18s  %-18s  %-18s  %-18s\n', ...
    'Point', 'numjac abs err', 'numjac rel err', 'cluster abs err', 'cluster rel err');
fprintf('%s\n', repmat('-', 1, 82));

probe_abs_cluster = zeros(1, n_probe);
probe_rel_cluster = zeros(1, n_probe);

for p = 1:n_probe
    xc = X_data(:, p);
    yc = Y_data(:, p);
    J_true = J_sym_fun(xc);
    J_num = numjac(Fo, xc);
    err_num_abs = norm(J_true - J_num, 'fro');
    err_num_rel = err_num_abs / (norm(J_true, 'fro') + eps);
    
    diffs    = X_data - xc;
    dists    = sqrt(sum(diffs.^2, 1));
    dists(p) = Inf;
    [~, idx] = sort(dists);
    nn_idx   = idx(1:K);
    
    dX = X_data(:, nn_idx) - xc;
    dY = Y_data(:, nn_idx) - yc;
    w  = 1 ./ sqrt(sum(dX.^2, 1));
    J_cl = (dY .* w) * pinv(dX .* w);
    
    err_cl_abs = norm(J_true - J_cl, 'fro');
    err_cl_rel = err_cl_abs / (norm(J_true, 'fro') + eps);
    probe_abs_cluster(p) = err_cl_abs;
    probe_rel_cluster(p) = err_cl_rel;
    
    fprintf('%-6d  %-18.2e  %-18.2e  %-18.2e  %-18.2e\n', ...
        p, err_num_abs, err_num_rel, err_cl_abs, err_cl_rel);
end
fprintf('Mean cluster relative error (probe): %.2e\n', mean(probe_rel_cluster));

T_cluster   = zeros(n, m, N);
slope_norms = zeros(m, N);
for c = 1:N
    xc = X_data(:,c);
    yc = Y_data(:,c);
    diffs    = X_data - xc;
    dists    = sqrt(sum(diffs.^2, 1));
    dists(c) = Inf;
    [~, idx] = sort(dists);
    nn_idx   = idx(1:K);
    
    dX = X_data(:, nn_idx) - xc;
    dY = Y_data(:, nn_idx) - yc;
    w    = 1 ./ sqrt(sum(dX.^2, 1));
    dX_w = dX .* w;
    dY_w = dY .* w;
    J_est = dY_w * pinv(dX_w);
    T_cluster(:,:,c) = J_est;
    for j = 1:m
        slope_norms(j,c) = norm(J_est(:,j));
    end
end

err_cl_abs = zeros(1, N);
err_cl_rel = zeros(1, N);
for k = 1:N
    J_true       = J_sym_fun(X_data(:,k));
    J_cl         = T_cluster(:,:,k);
    err_cl_abs(k) = norm(J_true - J_cl, 'fro');
    err_cl_rel(k) = err_cl_abs(k) / (norm(J_true, 'fro') + eps);
end

fprintf('\n=== Cluster Jacobian validation (K=%d, a=%.4f) ===\n', K, a);
fprintf('  Mean absolute Frobenius error: %.2e\n', mean(err_cl_abs));
fprintf('  Max  absolute Frobenius error: %.2e\n', max(err_cl_abs));
fprintf('  Mean relative Frobenius error: %.2e\n', mean(err_cl_rel));
fprintf('  Max  relative Frobenius error: %.2e\n', max(err_cl_rel));

fprintf('\nAverage Jacobian column norms (slope per input direction):\n');
for j = 1:m
    fprintf('  x%d direction: mean slope = %.4f\n', j, mean(slope_norms(j,:)));
end

figure('Name', 'Experiment C: Slope norms over data cloud');
for j = 1:m
    subplot(1, m, j);
    scatter(X_data(1,:), X_data(2,:), 20, slope_norms(j,:), 'filled');
    colorbar;
    xlabel('x_1');  ylabel('x_2');
    title(sprintf('||J(:,%d)||  (slope in x_%d direction)', j, j));
    axis equal;
end

cpd_tol      = 1e-2;
max_attempts = 10;
cpderror_cl  = Inf;
attempt      = 0;
while cpderror_cl >= cpd_tol && attempt < max_attempts
    attempt    = attempt + 1;
    res_cl     = cpd(T_cluster, r);
    W_cl       = res_cl{1};
    V_cl       = res_cl{2};
    cpderror_cl = norm(cpderr({Wo, Vo}, {W_cl, V_cl}));
    fprintf('CPD attempt %d: error = %.2e\n', attempt, cpderror_cl);
end

fprintf('\nWo (true):\n');  disp(Wo);
fprintf('W_cl (est):\n');   disp(W_cl);
fprintf('Vo (true):\n');    disp(Vo);
fprintf('V_cl (est):\n');   disp(V_cl);
fprintf('CPD error: %.2e  (after %d attempt(s))\n', cpderror_cl, attempt);

if cpderror_cl < cpd_tol
    disp('Good result! (cluster noise floor limits CPD to ~1e-3)');
else
    warning('CPD did not converge to a good solution after %d attempts.', max_attempts);
end

U_cl     = V_cl' * X_data;
Yhat_cl  = W_cl  \ Y_data;
U_mu_cl  = mean(U_cl, 2);
U_sig_cl = std(U_cl, 0, 2);
G_poly_cl = zeros(r, d+1);
for i = 1:r
    U_scaled       = (U_cl(i,:) - U_mu_cl(i)) / U_sig_cl(i);
    G_poly_cl(i,:) = polyfit(U_scaled, Yhat_cl(i,:), d);
end

% Using uniform box sampling to avoid zero-clustering on test set.
X_test = a * (2 * rand(m, N_test) - 1);
err_cl = zeros(1, N_test);
for k = 1:N_test
    u_k       = V_cl' * X_test(:,k);
    u_scaled  = (u_k - U_mu_cl) ./ U_sig_cl;
    g_k       = arrayfun(@(i) polyval(G_poly_cl(i,:), u_scaled(i)), (1:r)');
    err_cl(k) = norm(Fo(X_test(:,k)) - W_cl * g_k);
end
fprintf('RMS reconstruction error (cluster, K=%d): %.2e\n', K, sqrt(mean(err_cl.^2)));

K_values    = [3, 5, 10, 20, 50];
mean_cl_abs = zeros(size(K_values));
mean_cl_rel = zeros(size(K_values));
rms_cl_err  = zeros(size(K_values));

% Using uniform box sampling to avoid zero-clustering on fixed test set.
X_test_fixed = a * (2 * rand(m, N_test) - 1);

fprintf('\n%-6s  %-18s  %-18s  %-18s\n', 'K', 'Mean Jac Abs', 'Mean Jac Rel', 'RMS Recon');
fprintf('%s\n', repmat('-', 1, 66));

for ki = 1:numel(K_values)
    K_val  = K_values(ki);
    T_cl_k = zeros(n, m, N);
    for c = 1:N
        xc       = X_data(:,c);
        yc       = Y_data(:,c);
        diffs    = X_data - xc;
        dists    = sqrt(sum(diffs.^2, 1));
        dists(c) = Inf;
        [~, idx] = sort(dists);
        nn_idx   = idx(1:K_val);
        
        dX = X_data(:, nn_idx) - xc;
        dY = Y_data(:, nn_idx) - yc;
        w  = 1 ./ sqrt(sum(dX.^2, 1));
        T_cl_k(:,:,c) = (dY .* w) * pinv(dX .* w);
    end
    
    ej_abs = zeros(1, N);
    ej_rel = zeros(1, N);
    for k = 1:N
        J_true    = J_sym_fun(X_data(:,k));
        ej_abs(k) = norm(J_true - T_cl_k(:,:,k), 'fro');
        ej_rel(k) = ej_abs(k) / (norm(J_true, 'fro') + eps);
    end
    mean_cl_abs(ki) = mean(ej_abs);
    mean_cl_rel(ki) = mean(ej_rel);
    
    best_err = Inf;  Wc = []; Vc = [];
    for attempt = 1:max_attempts
        rc = cpd(T_cl_k, r);
        ce = norm(cpderr({Wo, Vo}, {rc{1}, rc{2}}));
        if ce < best_err
            best_err = ce;
            Wc = rc{1};  Vc = rc{2};
        end
        if best_err < cpd_tol, break; end
    end
    
    Uc  = Vc' * X_data;
    Yhc = Wc \ Y_data;
    Uc_mu  = mean(Uc, 2);
    Uc_sig = std(Uc, 0, 2);
    Gcp = zeros(r, d+1);
    for i = 1:r
        Us = (Uc(i,:) - Uc_mu(i)) / Uc_sig(i);
        Gcp(i,:) = polyfit(Us, Yhc(i,:), d);
    end
    
    err_k = zeros(1, N_test);
    for k = 1:N_test
        u_k      = Vc' * X_test_fixed(:,k);
        u_scaled = (u_k - Uc_mu) ./ Uc_sig;
        g_k      = arrayfun(@(i) polyval(Gcp(i,:), u_scaled(i)), (1:r)');
        err_k(k) = norm(Fo(X_test_fixed(:,k)) - Wc * g_k);
    end
    rms_cl_err(ki) = sqrt(mean(err_k.^2));
    fprintf('K = %-4d  abs = %-14.2e  rel = %-14.2e  rms = %-14.2e\n', ...
        K_val, mean_cl_abs(ki), mean_cl_rel(ki), rms_cl_err(ki));
end

figure('Name', 'Experiment C: Effect of cluster size K');
subplot(1,3,1);
semilogy(K_values, mean_cl_abs, 'b-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'b');
set(gca, 'XScale', 'log');
xlabel('K (neighbours)');  ylabel('Mean absolute Frobenius error');
title('K vs Jacobian error (abs)');  grid on;

subplot(1,3,2);
semilogy(K_values, mean_cl_rel, 'm-s', 'LineWidth', 1.5, 'MarkerFaceColor', 'm');
set(gca, 'XScale', 'log');
xlabel('K (neighbours)');  ylabel('Mean relative Frobenius error');
title('K vs Jacobian error (rel)');  grid on;

subplot(1,3,3);
semilogy(K_values, rms_cl_err, 'r-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'r');
set(gca, 'XScale', 'log');
xlabel('K (neighbours)');  ylabel('RMS reconstruction error');
title('K vs RMS error');  grid on;

annotation('textbox', [0.1, 0.01, 0.8, 0.06], 'String', ...
    ['Observation: The choice of neighborhood size K balances bias and variance. Small K values ', ...
     'suffer from high local noise variance, whereas excessively large K values induce truncation bias ', ...
     'by gathering distant points that violate the local linearity assumption across the uniform domain.'], ...
    'EdgeColor', 'none', 'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold');

function J = numjac(Fo, x, h)
    if nargin < 3, h = 1e-5; end
    fx = Fo(x);
    fx = fx(:);
    n  = numel(fx);
    m  = numel(x);
    J  = zeros(n, m);
    for j = 1:m
        xp    = x;
        xm    = x;
        xp(j) = xp(j) + h;
        xm(j) = xm(j) - h;
        fxp   = Fo(xp);
        fxm   = Fo(xm);
        J(:,j) = (fxp(:) - fxm(:)) / (2*h);
    end
end
