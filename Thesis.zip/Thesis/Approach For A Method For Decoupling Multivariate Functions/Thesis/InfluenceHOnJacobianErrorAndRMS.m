% Experiment: Influence of step size h on Jacobian error and RMS
% Sweeps h over several orders of magnitude and records:
%   - Mean Frobenius error (absolute AND relative) of the numerical
%     Jacobian vs symbolic
%   - RMS reconstruction error of the full pipeline

clear all; close all; clc;

%% PARAMETERS
m      = 2;    % number of inputs
n      = 2;    % number of outputs
r      = 2;    % rank (number of ridge functions)
d      = 3;    % polynomial degree for G recovery
N      = 500;  % number of training points
N_test = 200;  % number of test points
a      = 0.5;  % half-width of the box domain; tune this value as needed

syms u1 u2
Vo = [-3  0 ; ...
       1 -8 ];
Wo = [-2  3 ; ...
      -7 -4 ];
Go = [- 2*u1^3 +   u1^2 - 2*u1 ; - u2^3 + 7*u2^2 + 3*u2 + 2];

Fo_symbolic = expand(Wo*subs(Go,symvar(Go).',Vo'*sym('x', [1 m]).'));
Fo        = matlabFunction(Fo_symbolic, 'Vars', {sym('x', [m 1])});
xsym      = sym('x', [m 1]);
J_sym_fun = matlabFunction(jacobian(Fo_symbolic, xsym), 'Vars', {xsym});

% Fixed dataset — same X and Y for every h so comparisons are fair.
% Using uniform box sampling to avoid zero-clustering.
X = a * (2 * rand(m, N) - 1);
Y = zeros(n, N);
for k = 1:N
    Y(:,k) = Fo(X(:,k));
end

% Fixed test set — same for every h, strictly matching the training domain bounds.
X_test_fixed = a * (2 * rand(m, N_test) - 1);

%%Step sizes
h_values     = [1e-2, 1e-3, 1e-4, 1e-5, 1e-6, 1e-7, 1e-8];
mean_jac_abs = zeros(size(h_values));
mean_jac_rel = zeros(size(h_values));
rms_err      = zeros(size(h_values));
cpd_tol      = 1e-4;
max_attempts = 10;

fprintf('\n%-8s  %-18s  %-18s  %-18s\n', 'h', 'Jac Err (abs)', 'Jac Err (rel)', 'RMS Error');
fprintf('%s\n', repmat('-', 1, 68));

for hi = 1:numel(h_values)
    h_val = h_values(hi);
    
    % Build Jacobian tensor with this h
    T_h = zeros(n, m, N);
    for k = 1:N
        T_h(:,:,k) = numjac(Fo, X(:,k), h_val);
    end
    
    % Jacobian error vs symbolic (absolute and relative)
    ej_abs = zeros(1, N);
    ej_rel = zeros(1, N);
    for k = 1:N
        J_true    = J_sym_fun(X(:,k));
        ej_abs(k) = norm(J_true - T_h(:,:,k), 'fro');
        ej_rel(k) = ej_abs(k) / (norm(J_true, 'fro') + eps);
    end
    mean_jac_abs(hi) = mean(ej_abs);
    mean_jac_rel(hi) = mean(ej_rel);
    
    % CPD with retry — keep best solution
    best_cpd_err = Inf;
    W_h = []; V_h = [];
    for attempt = 1:max_attempts
        res_h = cpd(T_h, r);
        ce    = norm(cpderr({Wo, Vo}, {res_h{1}, res_h{2}}));
        if ce < best_cpd_err
            best_cpd_err = ce;
            W_h = res_h{1};
            V_h = res_h{2};
        end
        if best_cpd_err < cpd_tol, break; end
    end
    
    % Polynomial regression for G
    U_h      = V_h' * X;
    Yhat_h   = W_h  \ Y;
    U_mu_h   = mean(U_h, 2);
    U_sig_h  = std(U_h, 0, 2);
    G_poly_h = zeros(r, d+1);
    for i = 1:r
        U_scaled      = (U_h(i,:) - U_mu_h(i)) / U_sig_h(i);
        G_poly_h(i,:) = polyfit(U_scaled, Yhat_h(i,:), d);
    end
    
    % RMS on the FIXED held-out test set (same for every h)
    err_h = zeros(1, N_test);
    for k = 1:N_test
        u_k      = V_h' * X_test_fixed(:,k);
        u_scaled = (u_k - U_mu_h) ./ U_sig_h;
        g_k      = arrayfun(@(i) polyval(G_poly_h(i,:), u_scaled(i)), (1:r)');
        err_h(k) = norm(Fo(X_test_fixed(:,k)) - W_h * g_k);
    end
    rms_err(hi) = sqrt(mean(err_h.^2));
    
    fprintf('h = %-6.0e  abs = %-14.2e  rel = %-14.2e  rms = %-14.2e\n', ...
        h_val, mean_jac_abs(hi), mean_jac_rel(hi), rms_err(hi));
end

%%Plot results
fig = figure('Name', 'Experiment: Step-size influence on Truncation & Cancellation Errors', ...
    'Units', 'normalized', 'Position', [0.1, 0.1, 0.82, 0.55]);

ax1 = subplot(1,3,1);
loglog(h_values, mean_jac_abs, 'b-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'b');
xlabel('Step size h'); ylabel('Mean absolute Frobenius error');
title('h vs Jacobian error (abs)'); grid on;

ax2 = subplot(1,3,2);
loglog(h_values, mean_jac_rel, 'm-s', 'LineWidth', 1.5, 'MarkerFaceColor', 'm');
xlabel('Step size h'); ylabel('Mean relative Frobenius error');
title('h vs Jacobian error (rel)'); grid on;

ax3 = subplot(1,3,3);
loglog(h_values, rms_err, 'r-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'r');
xlabel('Step size h'); ylabel('RMS reconstruction error');
title('h vs RMS Error'); grid on;

step_axes = [ax1, ax2, ax3];
for i = 1:numel(step_axes)
    pos = get(step_axes(i), 'Position');
    pos(2) = 0.28; % Push floor upward clear of x-labels
    pos(4) = 0.58; % Shrink bounding height to balance composition
    set(step_axes(i), 'Position', pos);
end

annotation('textbox', [0.05, 0.02, 0.9, 0.14], 'String', ...
    ['Observation: The characteristic V-shape illustrates the tradeoff between truncation error (large h) ', ...
     'and machine floating-point cancellation error (small h). The optimal step size for minimizing ', ...
     'Jacobian estimation error and pipeline RMS reconstruction error is reached near h = 1e-5.'], ...
    'EdgeColor', 'none', 'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold');

%% LOCAL FUNCTIONS
function J = numjac(Fo, x, h)
    if nargin < 3, h = 1e-5; end
    fx = Fo(x);
    fx = fx(:);
    n  = numel(fx);
    m  = numel(x);
    J  = zeros(n, m);
    for j = 1:m
        xp    = x;
        xm    = x;
        xp(j) = xp(j) + h;
        xm(j) = xm(j) - h;
        fxp   = Fo(xp);
        fxm   = Fo(xm);
        J(:,j) = (fxp(:) - fxm(:)) / (2*h);
    end
end