% Multivariate nonlinear vector function decoupling
% using CPD of the Jacobian tensor and polynomial regression.
% Steps:
%   1. Build dataset Y and Jacobian tensor T
%   2. Validate numerical Jacobian against symbolic Jacobian (relative error)
%   3. Apply CPD to T to recover W and V  (with retry loop)
%   4. Recover G by polynomial regression
%   5. Validate reconstruction on a held-out test set
clear all; close all; clc;

%% PARAMETERS
m      = 2;    % number of inputs
n      = 2;    % number of outputs
r      = 2;    % rank (number of ridge functions)
d      = 3;    % polynomial degree for G recovery
N      = 500;  % number of training points
N_test = 200;  % number of test points
a      = 0.5;  % half-width of the box domain; tune this value as needed

% The true decoupled representation is given by:
%   F(x) = Wo * Go(Vo'*x),  where x = [x1; x2]
syms u1 u2
Vo = [-3  0 ; ...
       1 -8 ];
Wo = [-2  3 ; ...
      -7 -4 ];
Go = [- 2*u1^3 +   u1^2 - 2*u1 ; - u2^3 + 7*u2^2 + 3*u2 + 2];

% Sanity check: expanding Wo*Go(Vo'*x) symbolically should recover F.
Fo_symbolic = expand(Wo*subs(Go,symvar(Go).',Vo'*sym('x', [1 m]).'))
Fo        = matlabFunction(Fo_symbolic, 'Vars', {sym('x', [m 1])});
xsym      = sym('x', [m 1]);
J_sym_fun = matlabFunction(jacobian(Fo_symbolic, xsym), 'Vars', {xsym});

%% STEP 1: Build dataset and Jacobian tensor
%Using uniform sampling on [-a, a]^m to avoid clustering around 0
X = a * (2 * rand(m, N) - 1); 
Y = zeros(n, N);
T = zeros(n, m, N);
for k = 1:N
    xk       = X(:,k);
    Y(:,k)   = Fo(xk);
    T(:,:,k) = numjac(Fo, xk);
end

%% STEP 2: Validate numerical Jacobian against symbolic Jacobian
% We use both absolute AND relative Frobenius error.
% Relative error = ||J_sym - J_num||_F / ||J_sym||_F
% avoids misleading results when Jacobian entries are large.
err_jac_abs = zeros(1, N);
err_jac_rel = zeros(1, N);
for k = 1:N
    J_true        = J_sym_fun(X(:,k));
    J_num         = T(:,:,k);
    err_jac_abs(k) = norm(J_true - J_num, 'fro');
    err_jac_rel(k) = norm(J_true - J_num, 'fro') / (norm(J_true, 'fro') + eps);
end
fprintf('\n=== Jacobian validation over %d points ===\n', N);
fprintf('  Mean absolute Frobenius error: %.2e\n', mean(err_jac_abs));
fprintf('  Max  absolute Frobenius error: %.2e\n', max(err_jac_abs));
fprintf('  Mean relative Frobenius error: %.2e\n', mean(err_jac_rel));
fprintf('  Max  relative Frobenius error: %.2e\n', max(err_jac_rel));

%% STEP 3: CPD of the Jacobian tensor  (with retry loop)
% CPD uses local optimisation from a random starting point and may
% occasionally land in a local minimum.  We retry until the CPD error
% is below the threshold, or give up after max_attempts.
cpd_tol      = 1e-4;
max_attempts = 10;
cpderror_J   = Inf;
attempt      = 0;
while cpderror_J >= cpd_tol && attempt < max_attempts
    attempt = attempt + 1;
    res     = cpd(T, r);
    W_est   = res{1};
    V_est   = res{2};
    cpderror_J = norm(cpderr({Wo, Vo}, {W_est, V_est}));
    fprintf('CPD attempt %d: error = %.2e\n', attempt, cpderror_J);
end
fprintf('\nWo (true):\n');  disp(Wo);
fprintf('W_est (est):\n'); disp(W_est);
fprintf('Vo (true):\n');   disp(Vo);
fprintf('V_est (est):\n'); disp(V_est);
fprintf('CPD error: %.2e  (after %d attempt(s))\n', cpderror_J, attempt);
if cpderror_J < cpd_tol
    disp('Good result!');
else
    warning('CPD did not converge to a good solution after %d attempts.', max_attempts);
end

%% STEP 4: Recover G by polynomial regression
U    = V_est' * X;
Yhat = W_est \ Y;
U_mu  = mean(U, 2);
U_sig = std(U, 0, 2);
G_poly = zeros(r, d+1);
for i = 1:r
    U_scaled    = (U(i,:) - U_mu(i)) / U_sig(i);
    G_poly(i,:) = polyfit(U_scaled, Yhat(i,:), d);
end
fprintf('\nRecovered G coefficients (highest to lowest degree):\n');
for i = 1:r
    fprintf('  g%d: ', i);
    fprintf('%+.4f  ', G_poly(i,:));
    fprintf('\n');
end

%% STEP 5: Reconstruct F and validate on held-out test set
% Ensure test data matches the uniform box sampling domain of the training data
X_test = a * (2 * rand(m, N_test) - 1); 
err    = zeros(1, N_test);
for k = 1:N_test
    u_k      = V_est' * X_test(:,k);
    u_scaled = (u_k - U_mu) ./ U_sig;
    g_k      = arrayfun(@(i) polyval(G_poly(i,:), u_scaled(i)), (1:r)');
    err(k)   = norm(Fo(X_test(:,k)) - W_est * g_k);
end
fprintf('RMS reconstruction error: %.2e\n', sqrt(mean(err.^2)));

% Key metrics:
%   - Jacobian relative Frobenius error  ~  1e-7   (validates numjac)
%   - CPD error                          ~  0      (validates factor recovery)
%   - RMS reconstruction                 <  1e-3   (validates full pipeline)

function J = numjac(Fo, x, h)
    if nargin < 3, h = 1e-5; end
    fx = Fo(x);
    fx = fx(:);
    n  = numel(fx);
    m  = numel(x);
    J  = zeros(n, m);
    for j = 1:m
        xp    = x;
        xm    = x;
        xp(j) = xp(j) + h;
        xm(j) = xm(j) - h;
        fxp   = Fo(xp);
        fxm   = Fo(xm);
        J(:,j) = (fxp(:) - fxm(:)) / (2*h);
    end
end