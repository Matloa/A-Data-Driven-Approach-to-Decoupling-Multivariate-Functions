% Experiment: Fair comparison of three decoupling approaches on the
%             same uniformly-sampled data cloud.
%
%   Approach 2a : K-nearest-neighbour cluster Jacobian  (data-driven)
%   Approach 2b : fixed-radius cluster Jacobian         (data-driven)
%   Baseline    : polynomial-fit-then-decouple          (global fit)
%5
% All three:
%   - see the SAME inputs X (uniform sampling, not normal)
%   - see the SAME noisy outputs Y_noisy at each noise level
%   - produce a decoupled form  W * G(V'x)
%   - are scored by RMS on the same clean test set, plus CPD error
%     and (where a Jacobian tensor exists) relative Jacobian error.

clear all; close all; clc;

%% PARAMETERS
m      = 2;     % number of inputs
n      = 2;     % number of outputs
r      = 2;     % rank (number of ridge functions)
d      = 3;     % polynomial degree for G recovery / baseline
N      = 500;   % size of the shared data cloud
N_test = 200;   % number of clean test points

% Uniform sampling half-width (the box is [-box, box]^m).
box    = 0.05;

% Cluster hyper-parameters (chosen from the standalone sweeps).
K_nn   = 10;     % neighbours for Approach 2a
radius = 0.02;   % radius for Approach 2b  (tune to box)

% Noise levels (std of additive Gaussian output noise).
sigma_noise_values = [0, 0.001, 0.01, 0.1, 0.5, 1.0];

% CPD settings.
cpd_tol      = 1e-2;   % cluster noise floor limits CPD to ~1e-3
max_attempts = 10;

%% TRUE DECOUPLED REPRESENTATION  F(x) = Wo * Go(Vo'x)
syms u1 u2

Vo = [-3  0 ; ...
       1 -8 ];
Wo = [-2  3 ; ...
      -7 -4 ];
Go = [- 2*u1^3 +   u1^2 - 2*u1 ; - u2^3 + 7*u2^2 + 3*u2 + 2];

Fo_symbolic = expand(Wo*subs(Go,symvar(Go).',Vo'*sym('x', [1 m]).'));
Fo        = matlabFunction(Fo_symbolic, 'Vars', {sym('x', [m 1])});
xsym      = sym('x', [m 1]);
J_sym_fun = matlabFunction(jacobian(Fo_symbolic, xsym), 'Vars', {xsym});

%% SHARED DATA CLOUD  (UNIFORM sampling, identical for all methods)
rng(42);                              % reproducible
X = box * (2*rand(m, N) - 1);         % uniform on [-box, box]^m
Y_clean = zeros(n, N);
for k = 1:N
    Y_clean(:,k) = Fo(X(:,k));
end

% Shared clean test set
X_test = box * (2*rand(m, N_test) - 1);
Y_test = zeros(n, N_test);
for k = 1:N_test
    Y_test(:,k) = Fo(X_test(:,k));
end

% Polynomial feature matrices for the baseline (built once)
Phi_train = poly_features(X,      m, d);   % B x N
Phi_test  = poly_features(X_test, m, d);   % B x N_test
B_basis   = size(Phi_train, 1);

fprintf('Shared data cloud: N=%d uniform on [-%.3f, %.3f]^%d\n', N, box, box, m);
fprintf('Baseline polynomial basis: %d monomials (degree <= %d)\n\n', B_basis, d);

%% Pre-build the two cluster Jacobian tensors (depend on X, Y_clean only)

T_2a = build_knn_tensor   (X, Y_clean, K_nn,   m, n);
T_2b = build_radius_tensor(X, Y_clean, radius, m, n, Fo);

% Relative Jacobian error for each cluster method (noise-independent)
ej_2a = jac_rel_error(T_2a, X, J_sym_fun);
ej_2b = jac_rel_error(T_2b, X, J_sym_fun);

%% NOISELESS COMPARISON
fprintf('Noiseless comparison (sigma_n = 0) \n');
fprintf('%-22s  %-16s  %-12s  %-12s\n', ...
    'Method', 'Rel Jac err', 'CPD err', 'RMS recon');
fprintf('\n');

[rms_2a0, cpd_2a0] = run_cluster_pipeline(T_2a, X, Y_clean, ...
    X_test, Y_test, Wo, Vo, r, d, cpd_tol, max_attempts, Fo);
fprintf('%-22s  %-16.2e  %-12.2e  %-12.2e\n', ...
    'Cluster K-NN (2a)', mean(ej_2a), cpd_2a0, rms_2a0);

[rms_2b0, cpd_2b0] = run_cluster_pipeline(T_2b, X, Y_clean, ...
    X_test, Y_test, Wo, Vo, r, d, cpd_tol, max_attempts, Fo);
fprintf('%-22s  %-16.2e  %-12.2e  %-12.2e\n', ...
    'Cluster radius (2b)', mean(ej_2b), cpd_2b0, rms_2b0);

[rms_b0, cpd_b0, ejb0] = run_baseline_pipeline(X, Y_clean, Phi_train, ...
    X_test, Y_test, Wo, Vo, r, d, m, n, cpd_tol, max_attempts, J_sym_fun);
fprintf('%-22s  %-16.2e  %-12.2e  %-12.2e\n\n', ...
    'Poly-then-decouple', ejb0, cpd_b0, rms_b0);


%% NOISE SWEEP 
fprintf('Noise sweep: RMS on clean test set \n');
fprintf('%-10s  %-14s  %-14s  %-14s\n', ...
    'sigma_n', 'Cluster 2a', 'Cluster 2b', 'Poly-decouple');
fprintf('\n');

nL = numel(sigma_noise_values);
rms_2a = zeros(1, nL);
rms_2b = zeros(1, nL);
rms_b  = zeros(1, nL);

for si = 1:nL
    sig = sigma_noise_values(si);
    Y_noisy = Y_clean + sig * randn(n, N);   % SAME noise seen by all 3

    % 2a: cluster tensor fixed, noise enters G-regression
    rms_2a(si) = run_cluster_pipeline(T_2a, X, Y_noisy, ...
        X_test, Y_test, Wo, Vo, r, d, cpd_tol, max_attempts, Fo);

    % 2b: same
    rms_2b(si) = run_cluster_pipeline(T_2b, X, Y_noisy, ...
        X_test, Y_test, Wo, Vo, r, d, cpd_tol, max_attempts, Fo);

    % baseline: global polynomial fit on the same noisy data
    rms_b(si) = run_baseline_pipeline(X, Y_noisy, Phi_train, ...
        X_test, Y_test, Wo, Vo, r, d, m, n, cpd_tol, max_attempts, J_sym_fun);

    fprintf('%-10.3f  %-14.2e  %-14.2e  %-14.2e\n', ...
        sig, rms_2a(si), rms_2b(si), rms_b(si));
end

%% PLOT: RMS vs noise for all three methods
figure('Name', 'Core benchmark: 2a vs 2b vs fit-then-decouple');
semilogx(sigma_noise_values + 1e-4, rms_2a, 'b-o', 'LineWidth', 2, ...
    'MarkerFaceColor', 'b', 'DisplayName', 'Cluster K-NN (2a)');
hold on;
semilogx(sigma_noise_values + 1e-4, rms_2b, 'g-^', 'LineWidth', 2, ...
    'MarkerFaceColor', 'g', 'DisplayName', 'Cluster radius (2b)');
semilogx(sigma_noise_values + 1e-4, rms_b, 'r-s', 'LineWidth', 2, ...
    'MarkerFaceColor', 'r', 'DisplayName', 'Poly-then-decouple');
set(gca, 'YScale', 'log');
xlabel('Output noise level \sigma_n');
ylabel('RMS reconstruction error (clean test set)');
title('Same data cloud: data-driven (2a, 2b) vs fit-then-decouple');
legend('Location', 'northwest');
grid on;

%%   Run all three methods NOISELESS while sweeping the box half-width.
box_values = [0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.4];
nB = numel(box_values);
rms_2a_box = zeros(1, nB);
rms_2b_box = zeros(1, nB);
rms_b_box  = zeros(1, nB);
jac_2a_box = zeros(1, nB);

fprintf('\nSampling-region sweep (noiseless)\n');
fprintf('%-8s  %-14s  %-14s  %-14s\n', 'box', 'RMS 2a', 'RMS 2b', 'RMS base');
fprintf('\n');
for bi = 1:nB
    bx = box_values(bi);
    Xb = bx * (2*rand(m, N) - 1);
    Yb = zeros(n, N);
    for k = 1:N, Yb(:,k) = Fo(Xb(:,k)); end
    Xtb = bx * (2*rand(m, N_test) - 1);
    Ytb = zeros(n, N_test);
    for k = 1:N_test, Ytb(:,k) = Fo(Xtb(:,k)); end
    Phib = poly_features(Xb, m, d);

    Ta = build_knn_tensor(Xb, Yb, K_nn, m, n);
    Tb = build_radius_tensor(Xb, Yb, max(radius, 0.4*bx), m, n, Fo);
    jac_2a_box(bi) = mean(jac_rel_error(Ta, Xb, J_sym_fun));

    rms_2a_box(bi) = run_cluster_pipeline(Ta, Xb, Yb, Xtb, Ytb, ...
        Wo, Vo, r, d, cpd_tol, max_attempts, Fo);
    rms_2b_box(bi) = run_cluster_pipeline(Tb, Xb, Yb, Xtb, Ytb, ...
        Wo, Vo, r, d, cpd_tol, max_attempts, Fo);
    rms_b_box(bi) = run_baseline_pipeline(Xb, Yb, Phib, Xtb, Ytb, ...
        Wo, Vo, r, d, m, n, cpd_tol, max_attempts, J_sym_fun);

    fprintf('%-8.3f  %-14.2e  %-14.2e  %-14.2e\n', ...
        bx, rms_2a_box(bi), rms_2b_box(bi), rms_b_box(bi));
end

figure('Name', 'Effect of sampling region');
subplot(1,2,1);
loglog(box_values, jac_2a_box, 'b-o', 'LineWidth', 1.5, 'MarkerFaceColor','b');
hold on;
loglog(box_values, (8*box_values).^2, 'k--', 'LineWidth', 1.2);
xlabel('Sampling box half-width');
ylabel('Mean relative Jacobian error (2a)');
title('Cluster Jacobian error vs box');
legend('measured', '(c_{max}\sigma)^2 slope', 'Location', 'northwest');
grid on;
subplot(1,2,2);
loglog(box_values, rms_2a_box, 'b-o', 'LineWidth', 1.5, ...
    'MarkerFaceColor', 'b', 'DisplayName', 'Cluster 2a');
hold on;
loglog(box_values, rms_2b_box, 'g-^', 'LineWidth', 1.5, ...
    'MarkerFaceColor', 'g', 'DisplayName', 'Cluster 2b');
loglog(box_values, rms_b_box, 'r-s', 'LineWidth', 1.5, ...
    'MarkerFaceColor', 'r', 'DisplayName', 'Baseline');
xlabel('Sampling box half-width');
ylabel('RMS reconstruction error (noiseless)');
title('Reconstruction error vs box');
legend('Location', 'northwest');
grid on;

%% Neighbourhood-size sweep (2a) and radius sweep (2b)
%%   on a common axis of mean neighbour count (noiseless).

K_list   = [3, 5, 10, 20, 50];
rho_list = [0.005, 0.01, 0.02, 0.04, 0.08];

rms_K  = zeros(1, numel(K_list));
jac_K  = zeros(1, numel(K_list));
nn_K   = K_list;                      % mean neighbours = K by definition
for ki = 1:numel(K_list)
    Tk = build_knn_tensor(X, Y_clean, K_list(ki), m, n);
    jac_K(ki) = mean(jac_rel_error(Tk, X, J_sym_fun));
    rms_K(ki) = run_cluster_pipeline(Tk, X, Y_clean, X_test, Y_test, ...
        Wo, Vo, r, d, cpd_tol, max_attempts, Fo);
end

rms_R  = zeros(1, numel(rho_list));
jac_R  = zeros(1, numel(rho_list));
nn_R   = zeros(1, numel(rho_list));
for ri = 1:numel(rho_list)
    [Tr, cnt] = build_radius_tensor_count(X, Y_clean, rho_list(ri), m, n, Fo);
    nn_R(ri)  = mean(cnt);
    jac_R(ri) = mean(jac_rel_error(Tr, X, J_sym_fun));
    rms_R(ri) = run_cluster_pipeline(Tr, X, Y_clean, X_test, Y_test, ...
        Wo, Vo, r, d, cpd_tol, max_attempts, Fo);
end

figure('Name', 'Neighbourhood comparison on common axis');
subplot(1,2,1);
loglog(nn_K, jac_K, 'b-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'b', ...
    'DisplayName', 'K-NN (2a)');
hold on;
loglog(nn_R, jac_R, 'g-^', 'LineWidth', 1.5, 'MarkerFaceColor', 'g', ...
    'DisplayName', 'radius (2b)');
xlabel('Mean number of neighbours');
ylabel('Mean relative Jacobian error');
title('Jacobian error vs neighbourhood size');
legend('Location', 'best');
grid on;
subplot(1,2,2);
loglog(nn_K, rms_K, 'b-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'b', ...
    'DisplayName', 'K-NN (2a)');
hold on;
loglog(nn_R, rms_R, 'g-^', 'LineWidth', 1.5, 'MarkerFaceColor', 'g', ...
    'DisplayName', 'radius (2b)');
xlabel('Mean number of neighbours');
ylabel('RMS reconstruction error');
title('RMS vs neighbourhood size');
legend('Location', 'best');
grid on;

%%   Per-point Jacobian error over the data cloud (2a)
%%   Shows WHERE in input space the cluster estimate is weak.
ej_point = jac_rel_error(T_2a, X, J_sym_fun);
figure('Name', 'Spatial Jacobian error (2a)');
scatter(X(1,:), X(2,:), 25, log10(ej_point + eps), 'filled');
cb = colorbar; cb.Label.String = 'log_{10} relative Jacobian error';
xlabel('x_1'); ylabel('x_2');
title('Where the cluster Jacobian (2a) is accurate vs weak');
axis equal; grid on;

%%   Sampling coverage of the ridge functions g_i
%%   Plots where the projected samples u_i = v_i' x land on each g_i,
%%   revealing regions of g_i that are poorly covered.
U_true = Vo' * X;                  % r x N latent coordinates (true V)
gfun = {@(u) -2*u.^3 + u.^2 - 2*u, @(u) -u.^3 + 7*u.^2 + 3*u + 2};
figure('Name', 'Sampling coverage of g_i');
for i = 1:r
    subplot(1, r, i);
    ug = linspace(min(U_true(i,:)), max(U_true(i,:)), 200);
    plot(ug, gfun{i}(ug), 'k-', 'LineWidth', 1.5); hold on;
    plot(U_true(i,:), gfun{i}(U_true(i,:)), 'b.', 'MarkerSize', 6);
    xlabel(sprintf('u_%d = v_%d^T x', i, i));
    ylabel(sprintf('g_%d(u_%d)', i, i));
    title(sprintf('Coverage of g_%d', i));
    grid on;
end

%% LOCAL FUNCTIONS

function T = build_knn_tensor(X, Y, K, m, n)
    N = size(X, 2);
    T = zeros(n, m, N);
    for c = 1:N
        xc = X(:,c);  yc = Y(:,c);
        dists = sqrt(sum((X - xc).^2, 1));
        dists(c) = Inf;
        [~, idx] = sort(dists);
        nn = idx(1:K);
        dX = X(:, nn) - xc;
        dY = Y(:, nn) - yc;
        w  = 1 ./ sqrt(sum(dX.^2, 1));
        T(:,:,c) = (dY .* w) * pinv(dX .* w);
    end
end

function T = build_radius_tensor(X, Y, radius, m, n, Fo)
    N = size(X, 2);
    T = zeros(n, m, N);
    for c = 1:N
        xc = X(:,c);  yc = Y(:,c);
        dists = sqrt(sum((X - xc).^2, 1));
        in = (dists > 0) & (dists < radius);
        nn = find(in);
        if numel(nn) >= m + 1
            dX = X(:, nn) - xc;
            dY = Y(:, nn) - yc;
            w  = 1 ./ sqrt(sum(dX.^2, 1));
            T(:,:,c) = (dY .* w) * pinv(dX .* w);
        else
            T(:,:,c) = numjac(Fo, xc);   % fallback when too sparse
        end
    end
end

function [T, counts] = build_radius_tensor_count(X, Y, radius, m, n, Fo)
    N = size(X, 2);
    T = zeros(n, m, N);
    counts = zeros(1, N);
    for c = 1:N
        xc = X(:,c);  yc = Y(:,c);
        dists = sqrt(sum((X - xc).^2, 1));
        in = (dists > 0) & (dists < radius);
        nn = find(in);
        counts(c) = numel(nn);
        if numel(nn) >= m + 1
            dX = X(:, nn) - xc;
            dY = Y(:, nn) - yc;
            w  = 1 ./ sqrt(sum(dX.^2, 1));
            T(:,:,c) = (dY .* w) * pinv(dX .* w);
        else
            T(:,:,c) = numjac(Fo, xc);
        end
    end
end

function e = jac_rel_error(T, X, J_sym_fun)
    N = size(X, 2);
    e = zeros(1, N);
    for k = 1:N
        Jt = J_sym_fun(X(:,k));
        e(k) = norm(Jt - T(:,:,k), 'fro') / (norm(Jt, 'fro') + eps);
    end
end

function [rms, cpd_e] = run_cluster_pipeline(T, X, Y, X_test, Y_test, ...
        Wo, Vo, r, d, cpd_tol, max_attempts, ~)
    % CPD with retry (keep best)
    best = Inf; W = []; V = [];
    for a = 1:max_attempts
        rc = cpd(T, r);
        ce = norm(cpderr({Wo, Vo}, {rc{1}, rc{2}}));
        if ce < best, best = ce; W = rc{1}; V = rc{2}; end
        if best < cpd_tol, break; end
    end
    cpd_e = best;
    % G regression on  Y
    U  = V' * X;
    Yh = W \ Y;
    mu = mean(U, 2);  sg = std(U, 0, 2);
    G  = zeros(r, d+1);
    for i = 1:r
        G(i,:) = polyfit((U(i,:) - mu(i)) / sg(i), Yh(i,:), d);
    end
    % RMS on clean test
    err = zeros(1, size(X_test, 2));
    for k = 1:size(X_test, 2)
        uk = V' * X_test(:,k);
        us = (uk - mu) ./ sg;
        gk = arrayfun(@(i) polyval(G(i,:), us(i)), (1:r)');
        err(k) = norm(Y_test(:,k) - W * gk);
    end
    rms = sqrt(mean(err.^2));
end

function [rms, cpd_e, ej] = run_baseline_pipeline(X, Y, Phi, X_test, Y_test, ...
        Wo, Vo, r, d, m, n, cpd_tol, max_attempts, J_sym_fun)
    N = size(X, 2);
    % Fit global polynomial
    C = Y / Phi;                 % n x B  least-squares
    % Analytic Jacobian tensor from polynomial coefficients
    T = zeros(n, m, N);
    for k = 1:N
        for j = 1:m
            T(:,j,k) = C * poly_features_deriv(X(:,k), m, d, j);
        end
    end
    % Jacobian error vs symbolic (for the noiseless table)
    ej = mean(jac_rel_error(T, X, J_sym_fun));
    % CPD with retry
    best = Inf; W = []; V = [];
    for a = 1:max_attempts
        rc = cpd(T, r);
        ce = norm(cpderr({Wo, Vo}, {rc{1}, rc{2}}));
        if ce < best, best = ce; W = rc{1}; V = rc{2}; end
        if best < cpd_tol, break; end
    end
    cpd_e = best;
    % G regression on DENOISED polynomial output C*Phi
    Yvals = C * Phi;
    U  = V' * X;
    Yh = W \ Yvals;
    mu = mean(U, 2);  sg = std(U, 0, 2);
    G  = zeros(r, d+1);
    for i = 1:r
        G(i,:) = polyfit((U(i,:) - mu(i)) / sg(i), Yh(i,:), d);
    end
    err = zeros(1, size(X_test, 2));
    for k = 1:size(X_test, 2)
        uk = V' * X_test(:,k);
        us = (uk - mu) ./ sg;
        gk = arrayfun(@(i) polyval(G(i,:), us(i)), (1:r)');
        err(k) = norm(Y_test(:,k) - W * gk);
    end
    rms = sqrt(mean(err.^2));
end

function Phi = poly_features(X, m, d)
    N = size(X, 2);
    E = build_exponents(m, d);
    B = size(E, 1);
    Phi = ones(B, N);
    for b = 1:B
        for j = 1:m
            Phi(b,:) = Phi(b,:) .* (X(j,:) .^ E(b,j));
        end
    end
end

function dPhi = poly_features_deriv(x, m, d, j)
    E = build_exponents(m, d);
    B = size(E, 1);
    dPhi = zeros(B, 1);
    for b = 1:B
        ej = E(b, j);
        if ej == 0, dPhi(b) = 0; continue; end
        val = ej;
        for jj = 1:m
            if jj == j
                val = val * x(jj)^(ej - 1);
            else
                val = val * x(jj)^E(b,jj);
            end
        end
        dPhi(b) = val;
    end
end

function E = build_exponents(m, d)
    E = [];
    for total = 0:d
        E = [E; exponent_combos(m, total)];
    end
end

function C = exponent_combos(m, total)
    if m == 1
        C = total;
    else
        C = [];
        for k = 0:total
            sub = exponent_combos(m-1, total-k);
            C = [C; k*ones(size(sub,1),1), sub];
        end
    end
end

function J = numjac(Fo, x, h)
    if nargin < 3, h = 1e-5; end
    fx = Fo(x); fx = fx(:);
    n = numel(fx); m = numel(x);
    J = zeros(n, m);
    for j = 1:m
        xp = x; xm = x;
        xp(j) = xp(j) + h;  xm(j) = xm(j) - h;
        J(:,j) = (Fo(xp) - Fo(xm)) / (2*h);
    end
end