% Experiment: Optimal training size vs noise level
%   - The Jacobian tensor T is built with numjac (accurate, as in demo.m)
%   - CPD recovers W and V correctly (unaffected by output noise)
%   - Only the regression  W\Y_noisy  is affected by noise
%   - More training points N_reg -> better noise averaging -> lower RMS
% N_reg is extended to 10000 
clear all; close all; clc;

%% PARAMETERS
m      = 2;     % number of inputs
n      = 2;     % number of outputs
r      = 2;     % rank (number of ridge functions)
d      = 3;     % polynomial degree for G recovery
N      = 10000; % total training points (extended to cover full N_reg range)
N_test = 500;   % number of test points
a      = 0.5;   % half-width of the box domain; tune this value as needed

% The true decoupled representation:  F(x) = Wo * Go(Vo'*x)
syms u1 u2
Vo = [-3  0 ; ...
       1 -8 ];
Wo = [-2  3 ; ...
      -7 -4 ];
Go = [- 2*u1^3 +   u1^2 - 2*u1 ; - u2^3 + 7*u2^2 + 3*u2 + 2];

Fo_symbolic = expand(Wo*subs(Go,symvar(Go).',Vo'*sym('x', [1 m]).'));
Fo        = matlabFunction(Fo_symbolic, 'Vars', {sym('x', [m 1])});
xsym      = sym('x', [m 1]);
J_sym_fun = matlabFunction(jacobian(Fo_symbolic, xsym), 'Vars', {xsym});

%%Build full dataset and Jacobian tensor
fprintf('Building dataset and Jacobian tensor (N=%d)...\n', N);
% Using uniform box sampling to avoid zero-clustering.
X       = a * (2 * rand(m, N) - 1);
Y_clean = zeros(n, N);
T       = zeros(n, m, N);
for k = 1:N
    Y_clean(:,k) = Fo(X(:,k));
    T(:,:,k)     = numjac(Fo, X(:,k));
end

fprintf('Running CPD...\n');
cpd_tol      = 1e-4;
max_attempts = 10;
cpderr_val   = Inf;
for attempt = 1:max_attempts
    res   = cpd(T, r);
    W_est = res{1};
    V_est = res{2};
    cpderr_val = norm(cpderr({Wo, Vo}, {W_est, V_est}));
    if cpderr_val < cpd_tol, break; end
end
fprintf('CPD error: %.2e  ', cpderr_val);
if cpderr_val < cpd_tol
    fprintf('(Good)\n\n');
else
    fprintf('(Warning: possible local minimum)\n\n');
end

% Project all inputs — fixed for all regression experiments
U_all = V_est' * X;   % r x N

% Fixed clean test set — same distribution as training data
X_test_fixed = a * (2 * rand(m, N_test) - 1);

% N_reg extended to 10000 to find where curves genuinely plateau.
sigma_noise_values = [0, 0.001, 0.01, 0.1, 0.5, 1.0];
N_reg_values       = [10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000];
rms_grid = zeros(numel(sigma_noise_values), numel(N_reg_values));

fprintf('%-12s  %-8s  %-20s\n', 'sigma_noise', 'N_reg', 'RMS Recon Error');
fprintf('%s\n', repmat('-', 1, 44));

for si = 1:numel(sigma_noise_values)
    sig     = sigma_noise_values(si);
    Y_noisy = Y_clean + sig * randn(n, N);
    for ni = 1:numel(N_reg_values)
        N_reg = N_reg_values(ni);
        
        % Use first N_reg points for regression
        U_reg    = U_all(:, 1:N_reg);
        Yhat_reg = W_est \ Y_noisy(:, 1:N_reg);
        U_mu  = mean(U_reg, 2);
        U_sig = std(U_reg, 0, 2);
        
        G_poly = zeros(r, d+1);
        for i = 1:r
            Us = (U_reg(i,:) - U_mu(i)) / U_sig(i);
            G_poly(i,:) = polyfit(Us, Yhat_reg(i,:), d);
        end
        
        % RMS on FIXED clean test set (same for all runs)
        err = zeros(1, N_test);
        for k = 1:N_test
            u_k      = V_est' * X_test_fixed(:,k);
            u_scaled = (u_k - U_mu) ./ U_sig;
            g_k      = arrayfun(@(i) polyval(G_poly(i,:), u_scaled(i)), (1:r)');
            err(k)   = norm(Fo(X_test_fixed(:,k)) - W_est * g_k);
        end
        rms_grid(si, ni) = sqrt(mean(err.^2));
        fprintf('sig = %-7.3f  N_reg = %-6d  rms = %.2e\n', ...
            sig, N_reg, rms_grid(si, ni));
    end
end

%%Find optimal N_reg for each noise level
fprintf('\n%-12s  %-12s  %-20s\n', 'sigma_noise', 'Optimal N_reg', 'Best RMS');
fprintf('%s\n', repmat('-', 1, 48));
optimal_N = zeros(1, numel(sigma_noise_values));
for si = 1:numel(sigma_noise_values)
    [best_rms, best_ni] = min(rms_grid(si,:));
    optimal_N(si) = N_reg_values(best_ni);
    fprintf('sig = %-7.3f  N* = %-8d  rms* = %.2e\n', ...
        sigma_noise_values(si), optimal_N(si), best_rms);
end

%% Plotting
figure('Name', 'Experiment F: RMS vs N_reg for each noise level');
colors = lines(numel(sigma_noise_values));
hold on;
for si = 1:numel(sigma_noise_values)
    plot(N_reg_values, rms_grid(si,:), '-o', 'Color', colors(si,:), ...
        'LineWidth', 1.5, 'MarkerFaceColor', colors(si,:), ...
        'DisplayName', sprintf('\\sigma = %.3f', sigma_noise_values(si)));
end
set(gca, 'YScale', 'log', 'XScale', 'log');
xlabel('Number of training points for regression  N_{reg}');
ylabel('RMS reconstruction error');
title('RMS vs training size for each noise level');
legend('Location', 'northeast');
grid on;

figure('Name', 'Experiment F: Optimal N_reg vs noise level');
semilogx(sigma_noise_values + 1e-4, optimal_N, 'k-o', ...
    'LineWidth', 2, 'MarkerFaceColor', 'k', 'MarkerSize', 8);
xlabel('Noise level \sigma_{noise}');
ylabel('Optimal N_{reg} (training points for regression)');
title('How many training points are needed vs noise level?');
grid on;

% yellow = low error (good), blue = high error (bad)
figure('Name', 'Experiment F: RMS heatmap (noise x N_reg)');
imagesc(log10(N_reg_values), 1:numel(sigma_noise_values), log10(rms_grid));
cb = colorbar;
cb.Label.String = 'log_{10}(RMS)';
xlabel('log_{10}(N_{reg})');
ylabel('Noise level \sigma_{noise}');
yticks(1:numel(sigma_noise_values));
yticklabels(arrayfun(@(s) sprintf('%.3f', s), sigma_noise_values, 'UniformOutput', false));
title('log_{10}(RMS) — yellow = low error (good), blue = high error (bad)');
colormap(flipud(parula));

annotation('textbox', [0.1, 0.01, 0.8, 0.06], 'String', ...
    ['Observation: Under uniform box sampling, increasing the sample pool size N_{reg} ', ...
     'dampens out additive output measurement variances. The polynomial mapping errors systematically flatten ', ...
     'once the statistical distribution is sufficiently filled over the entire localized operations domain.'], ...
    'EdgeColor', 'none', 'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold');

%% LOCAL FUNCTIONS
function J = numjac(Fo, x, h)
    if nargin < 3, h = 1e-5; end
    fx = Fo(x);
    fx = fx(:);
    n  = numel(fx);
    m  = numel(x);
    J  = zeros(n, m);
    for j = 1:m
        xp    = x;
        xm    = x;
        xp(j) = xp(j) + h;
        xm(j) = xm(j) - h;
        fxp   = Fo(xp);
        fxm   = Fo(xm);
        J(:,j) = (fxp(:) - fxm(:)) / (2*h);
    end
end