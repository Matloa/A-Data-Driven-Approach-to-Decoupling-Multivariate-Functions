% Experiment: Radius-based neighbourhood Jacobian approximation
clear all; close all; clc;
set(groot, 'defaultAxesInteractions', []);

%% PARAMETERS
m      = 2;
n      = 2;
r      = 2;
d      = 3;
N      = 500;
N_test = 200;
a      = 0.5;                       % half-width of the box domain; tune this value as needed
radius = 0.004 * (a / 0.01);        % scale base radius proportionally with the uniform domain size

syms u1 u2
Vo = [-3  0 ; ...
       1 -8 ];
Wo = [-2  3 ; ...
      -7 -4 ];
Go = [- 2*u1^3 +   u1^2 - 2*u1 ; - u2^3 + 7*u2^2 + 3*u2 + 2];

Fo_symbolic = expand(Wo*subs(Go,symvar(Go).',Vo'*sym('x', [1 m]).'));
Fo        = matlabFunction(Fo_symbolic, 'Vars', {sym('x', [m 1])});
xsym      = sym('x', [m 1]);
J_sym_fun = matlabFunction(jacobian(Fo_symbolic, xsym), 'Vars', {xsym});

% Using uniform box sampling to avoid zero-clustering.
X_data = a * (2 * rand(m, N) - 1);
Y_data = zeros(n, N);
for k = 1:N
    Y_data(:,k) = Fo(X_data(:,k));
end

% Using uniform box sampling to avoid zero-clustering on fixed test set.
X_test_fixed = a * (2 * rand(m, N_test) - 1);

[T_radius, n_neighbours] = radius_jacobian(X_data, Y_data, radius, m, n, Fo);

fprintf('\n=== Radius-based Jacobian (radius=%.4f, a=%.3f) ===\n', radius, a);
fprintf('  Mean neighbours per point : %.1f\n', mean(n_neighbours));
fprintf('  Min  neighbours per point : %d\n',   min(n_neighbours));
fprintf('  Max  neighbours per point : %d\n',   max(n_neighbours));
fprintf('  Points using fallback (<%d neighbours): %d / %d\n', ...
    m+1, sum(n_neighbours < m+1), N);

err_radius = zeros(1, N);
for k = 1:N
    J_true       = J_sym_fun(X_data(:,k));
    err_radius(k) = norm(J_true - T_radius(:,:,k), 'fro') / (norm(J_true,'fro') + eps);
end

fprintf('\nJacobian validation (relative Frobenius error):\n');
fprintf('  Mean: %.2e\n', mean(err_radius));
fprintf('  Max:  %.2e\n', max(err_radius));

cpd_tol      = 5e-2;
max_attempts = 10;
best_err     = Inf; W_r = []; V_r = [];
for attempt = 1:max_attempts
    rc = cpd(T_radius, r);
    ce = norm(cpderr({Wo, Vo}, {rc{1}, rc{2}}));
    if ce < best_err
        best_err = ce;
        W_r = rc{1}; V_r = rc{2};
    end
    if best_err < cpd_tol, break; end
end

fprintf('\nWo (true):\n');  disp(Wo);
fprintf('W_r (est):\n');    disp(W_r);
fprintf('Vo (true):\n');    disp(Vo);
fprintf('V_r (est):\n');    disp(V_r);
fprintf('CPD error: %.2e\n', best_err);

if best_err < cpd_tol
    disp('Good result!');
else
    warning('Possible local minimum — try rerunning');
end

U_r     = V_r' * X_data;
Yhat_r  = W_r  \ Y_data;
U_mu_r  = mean(U_r, 2);
U_sig_r = std(U_r, 0, 2);

G_poly_r = zeros(r, d+1);
for i = 1:r
    U_scaled      = (U_r(i,:) - U_mu_r(i)) / U_sig_r(i);
    G_poly_r(i,:) = polyfit(U_scaled, Yhat_r(i,:), d);
end

err_r = zeros(1, N_test);
for k = 1:N_test
    u_k      = V_r' * X_test_fixed(:,k);
    u_scaled = (u_k - U_mu_r) ./ U_sig_r;
    g_k      = arrayfun(@(i) polyval(G_poly_r(i,:), u_scaled(i)), (1:r)');
    err_r(k) = norm(Fo(X_test_fixed(:,k)) - W_r * g_k);
end
fprintf('RMS reconstruction error (radius=%.4f): %.2e\n', radius, sqrt(mean(err_r.^2)));

% Adjust radius sweeps to scale cleanly inside the bounding box domain
radius_values = [0.001, 0.002, 0.004, 0.006, 0.008, 0.012, 0.018] * (a / 0.01);
mean_rad_err  = zeros(size(radius_values));
rms_rad_err   = zeros(size(radius_values));
mean_nn_count = zeros(size(radius_values));

fprintf('\n%-9s  %-12s  %-20s  %-20s\n', ...
    'Radius', 'Mean #nbrs', 'Mean Jac Rel Error', 'RMS Recon Error');
fprintf('%s\n', repmat('-', 1, 65));

for ri = 1:numel(radius_values)
    rad = radius_values(ri);
    [T_rad_i, nn_i] = radius_jacobian(X_data, Y_data, rad, m, n, Fo);
    mean_nn_count(ri) = mean(nn_i);
    
    ej = zeros(1, N);
    for k = 1:N
        J_true = J_sym_fun(X_data(:,k));
        ej(k)  = norm(J_true - T_rad_i(:,:,k), 'fro') / (norm(J_true,'fro') + eps);
    end
    mean_rad_err(ri) = mean(ej);
    
    try
        best_err_r = Inf; Wc = []; Vc = [];
        for attempt = 1:max_attempts
            rc = cpd(T_rad_i, r);
            ce = norm(cpderr({Wo, Vo}, {rc{1}, rc{2}}));
            if ce < best_err_r
                best_err_r = ce;
                Wc = rc{1}; Vc = rc{2};
            end
            if best_err_r < cpd_tol, break; end
        end
        
        Uc  = Vc' * X_data;
        Yhc = Wc \ Y_data;
        Uc_mu  = mean(Uc, 2);
        Uc_sig = std(Uc, 0, 2);
        
        Gcp = zeros(r, d+1);
        for i = 1:r
            Us = (Uc(i,:) - Uc_mu(i)) / Uc_sig(i);
            Gcp(i,:) = polyfit(Us, Yhc(i,:), d);
        end
        
        err_i = zeros(1, N_test);
        for k = 1:N_test
            u_k      = Vc' * X_test_fixed(:,k);
            u_scaled = (u_k - Uc_mu) ./ Uc_sig;
            g_k      = arrayfun(@(i) polyval(Gcp(i,:), u_scaled(i)), (1:r)');
            err_i(k) = norm(Fo(X_test_fixed(:,k)) - Wc * g_k);
        end
        rms_rad_err(ri) = sqrt(mean(err_i.^2));
    catch
        rms_rad_err(ri) = NaN;
    end
    
    fprintf('r = %-8.4f  mean_nn = %-6.1f  mean_jac = %-14.2e  rms = %-14.2e\n', ...
        rad, mean_nn_count(ri), mean_rad_err(ri), rms_rad_err(ri));
end

K_values      = [3, 5, 10, 20, 50];
mean_knn_err  = zeros(size(K_values));
rms_knn_err   = zeros(size(K_values));
mean_knn_dist = zeros(size(K_values));

fprintf('\n%-6s  %-16s  %-20s  %-20s\n', ...
    'K', 'Mean dist to Kth', 'Mean Jac Rel Error', 'RMS Recon Error');
fprintf('%s\n', repmat('-', 1, 66));

for ki = 1:numel(K_values)
    K_val  = K_values(ki);
    T_knn  = zeros(n, m, N);
    kth_dist = zeros(1, N);
    
    for c = 1:N
        xc       = X_data(:,c);
        yc       = Y_data(:,c);
        diffs    = X_data - xc;
        dists    = sqrt(sum(diffs.^2, 1));
        dists(c) = Inf;
        [sorted_d, idx] = sort(dists);
        kth_dist(c) = sorted_d(K_val);
        
        nn_idx   = idx(1:K_val);
        dX = X_data(:, nn_idx) - xc;
        dY = Y_data(:, nn_idx) - yc;
        
        w  = 1 ./ sqrt(sum(dX.^2, 1));
        T_knn(:,:,c) = (dY .* w) * pinv(dX .* w);
    end
    mean_knn_dist(ki) = mean(kth_dist);
    
    ej = zeros(1, N);
    for k = 1:N
        J_true = J_sym_fun(X_data(:,k));
        ej(k)  = norm(J_true - T_knn(:,:,k), 'fro') / (norm(J_true,'fro') + eps);
    end
    mean_knn_err(ki) = mean(ej);
    
    try
        best_err_k = Inf; Wc = []; Vc = [];
        for attempt = 1:max_attempts
            rc = cpd(T_knn, r);
            ce = norm(cpderr({Wo, Vo}, {rc{1}, rc{2}}));
            if ce < best_err_k
                best_err_k = ce;
                Wc = rc{1}; Vc = rc{2};
            end
            if best_err_k < cpd_tol, break; end
        end
        
        Uc  = Vc' * X_data;
        Yhc = Wc \ Y_data;
        Uc_mu  = mean(Uc, 2);
        Uc_sig = std(Uc, 0, 2);
        
        Gcp = zeros(r, d+1);
        for i = 1:r
            Us = (Uc(i,:) - Uc_mu(i)) / Uc_sig(i);
            Gcp(i,:) = polyfit(Us, Yhc(i,:), d);
        end
        
        err_k = zeros(1, N_test);
        for k = 1:N_test
            u_k      = Vc' * X_test_fixed(:,k);
            u_scaled = (u_k - Uc_mu) ./ Uc_sig;
            g_k      = arrayfun(@(i) polyval(Gcp(i,:), u_scaled(i)), (1:r)');
            err_k(k) = norm(Fo(X_test_fixed(:,k)) - Wc * g_k);
        end
        rms_knn_err(ki) = sqrt(mean(err_k.^2));
    catch
        rms_knn_err(ki) = NaN;
    end
    
    fprintf('K = %-4d  mean_dist = %-8.4f  mean_jac = %-14.2e  rms = %-14.2e\n', ...
        K_val, mean_knn_dist(ki), mean_knn_err(ki), rms_knn_err(ki));
end

%% PLOTTING
fig1 = figure('Name', 'Experiment D: Radius vs K-nearest-neighbours', 'Units', 'normalized', 'Position', [0.1, 0.1, 0.7, 0.7]);
subplot(2,2,1);
loglog(radius_values, mean_rad_err, 'b-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'b');
xlabel('Radius'); ylabel('Mean relative Frobenius error');
title('Radius-based: Jacobian error vs radius'); grid on;

subplot(2,2,2);
loglog(radius_values, rms_rad_err, 'r-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'r');
xlabel('Radius'); ylabel('RMS reconstruction error');
title('Radius-based: RMS error vs radius'); grid on;

subplot(2,2,3);
loglog(K_values, mean_knn_err, 'b-s', 'LineWidth', 1.5, 'MarkerFaceColor', 'b');
xlabel('K (neighbours)'); ylabel('Mean relative Frobenius error');
title('K-nearest: Jacobian error vs K'); grid on;

subplot(2,2,4);
loglog(K_values, rms_knn_err, 'r-s', 'LineWidth', 1.5, 'MarkerFaceColor', 'r');
xlabel('K (neighbours)'); ylabel('RMS reconstruction error');
title('K-nearest: RMS error vs K'); grid on;

fig2 = figure('Name', 'Experiment D: Direct comparison on common x-axis', 'Units', 'normalized', 'Position', [0.1, 0.1, 0.8, 0.6]);
ax1 = subplot(1,2,1);
loglog(mean_nn_count, mean_rad_err, 'b-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'b', 'DisplayName', 'Radius-based');
hold on;
loglog(K_values, mean_knn_err, 'r-s', 'LineWidth', 1.5, 'MarkerFaceColor', 'r', 'DisplayName', 'K-nearest');
xlabel('Mean number of neighbours used'); ylabel('Mean relative Jacobian Frobenius error');
title('Jacobian error: radius vs K-nearest'); legend('Location', 'best'); grid on;

all_err = [mean_rad_err(:); mean_knn_err(:)];
all_err = all_err(isfinite(all_err) & all_err > 0);
if ~isempty(all_err), ylim([0.9*min(all_err), 1.1*max(all_err)]); end

ax2 = subplot(1,2,2);
loglog(mean_nn_count, rms_rad_err, 'b-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'b', 'DisplayName', 'Radius-based');
hold on;
loglog(K_values, rms_knn_err, 'r-s', 'LineWidth', 1.5, 'MarkerFaceColor', 'r', 'DisplayName', 'K-nearest');
xlabel('Mean number of neighbours used'); ylabel('RMS reconstruction error');
title('RMS error: radius vs K-nearest'); legend('Location', 'best'); grid on;

all_rms = [rms_rad_err(:); rms_knn_err(:)];
all_rms = all_rms(isfinite(all_rms) & all_rms > 0);
if ~isempty(all_rms), ylim([0.9*min(all_rms), 1.1*max(all_rms)]); end

comp_axes = [ax1, ax2];
for i = 1:numel(comp_axes)
    pos = get(comp_axes(i), 'Position');
    set(comp_axes(i), 'Position', pos);
end

% Set active figure context to the main validation plot before anchoring text
figure(fig2);
annotation('textbox', [0.05, 0.02, 0.9, 0.14], 'String', ...
    ['Observation: Comparing fixed radius vs fixed K neighborhood sizes displays distinct convergence profiles. ', ...
     'Under uniform box sampling, radius boundaries maintain structural bias consistency but risk sparse zones, ', ...
     'whereas K-nearest models guarantee data allocation size while flexing physical boundary constraints over the tracking region.'], ...
    'EdgeColor', 'none', 'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold');

%% LOCAL FUNCTIONS
function [T, n_neighbours] = radius_jacobian(X_data, Y_data, radius, m, n, Fo)
    N = size(X_data, 2);
    T            = zeros(n, m, N);
    n_neighbours = zeros(1, N);
    for c = 1:N
        xc = X_data(:,c);
        yc = Y_data(:,c);
        diffs = X_data - xc;
        dists = sqrt(sum(diffs.^2, 1));
        in_radius = (dists > 0) & (dists < radius);
        nn_idx = find(in_radius);
        n_neighbours(c) = numel(nn_idx);
        if numel(nn_idx) >= m + 1
            dX = X_data(:, nn_idx) - xc;
            dY = Y_data(:, nn_idx) - yc;
            w    = 1 ./ sqrt(sum(dX.^2, 1));
            dX_w = dX .* w;
            dY_w = dY .* w;
            T(:,:,c) = dY_w * pinv(dX_w);
        else
            T(:,:,c) = numjac(Fo, xc);
        end
    end
end

function J = numjac(Fo, x, h)
    if nargin < 3, h = 1e-5; end
    fx = Fo(x);
    fx = fx(:);
    n  = numel(fx);
    m  = numel(x);
    J  = zeros(n, m);
    for j = 1:m
        xp    = x;
        xm    = x;
        xp(j) = xp(j) + h;
        xm(j) = xm(j) - h;
        fxp   = Fo(xp);
        fxm   = Fo(xm);
        J(:,j) = (fxp(:) - fxm(:)) / (2*h);
    end
end